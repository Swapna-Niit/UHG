package multipleinheritance;

public interface city {
	public  void readcity();

}
