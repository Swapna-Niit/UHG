package multipleinheritance;

public interface address {
	 default void readadress(){
		System.out.println("address");
	}

}
