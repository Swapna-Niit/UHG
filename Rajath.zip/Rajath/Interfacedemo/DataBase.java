package Interfacedemo;

public interface DataBase {
	int a=30;
	void cab();
	default void connectvalues()
	{System.out.println("a");

}
	static void values()
	{

}
}