package Interfacedemo;

//public class DataBaseImp implements DataBase {

//	public static void main(String[] args) {
		
	//	System.out.println(a);
		

//	}

//}
