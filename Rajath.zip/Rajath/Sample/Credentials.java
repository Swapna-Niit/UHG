package Sample;
import java.util.Scanner;
public class Credentials extends BankAccount {
	static int accr=1000000;
  
	public Credentials(String a, float b) {
		super(a, b);
		// TODO Auto-generated constructor stub
		Scanner s=new Scanner(System.in);
		accr++;
		System.out.println("ur acccount "+accr);
		
	}
	
	
	 void mincheck(){
		 if(bal<=2000)
		 {
			 bal=bal-1500;
		 }
		 
		
	 
		 
	 
}}
