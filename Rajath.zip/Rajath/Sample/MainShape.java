package Sample;

public class MainShape {

	public static void main(String[] args) {
	TriangleS a=new TriangleS();

	}

}
