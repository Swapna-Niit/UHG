package Sample;
import java.util.Scanner;

public class TriangleS extends shapes {
	int l,h,b;
	Scanner s=new Scanner(System.in);
	TriangleS(){
		System.out.println("triangle");
			
	}
	void area(){
		int area=s.nextInt();
			
	}

	void perimeter(){
		int perimeter=s.nextInt();
			
	}
	void readlength(){
		int length=s.nextInt();
			
	}

	void readheight(){
		int height=s.nextInt();
			
	}

}
