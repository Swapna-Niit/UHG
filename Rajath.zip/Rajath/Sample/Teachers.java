package Sample;

public class Teachers {
	int tid,sal;
	static int count=0;
	Teachers(){
		count++;
		tid=count;
		sal=100000;
	}

}
