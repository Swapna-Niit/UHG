package Sample;

import java.util.Scanner;

public class automorphic {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		long num;
		System.out.println("enter the number");
		num=s.nextInt();
        long x=num*num;
        String d=String.valueOf(num);
        int length=d.length();
        System.out.println(length);
        int y=10;
        for(int i=1;i<length;i++){
        	y=y*10;
        }
        System.out.println(y);
        long z=x%y;
        if ((z%num)== 0)
System.out.println("automorphic");
        else
        	System.out.println("not");
        	
	}
	

}
