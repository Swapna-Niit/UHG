package Sample;

public class Square {

}
