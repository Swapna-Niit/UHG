package Sample;

import java.util.Scanner;

public class Triangle {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the angles");
		int a=s.nextInt();
		int b=s.nextInt();
		int c=s.nextInt();
		if((a+b+c)==180 && (a==90||b==90||c==90))
    System.out.println("right angle");
       else
    	System.out.println("not right angle");
    	
		s.close();
	}

}
