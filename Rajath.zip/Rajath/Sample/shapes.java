package Sample;

public class shapes {
	shapes(){
		System.out.println("shape");
			
	}

	void area(){
		System.out.println("area");
			
	}

	void perimeter(){
		System.out.println("perimeter");
			
	}
	void readlength(){
		System.out.println("length");
			
	}
	void readbreadth(){
		System.out.println("breath");
			
	}

}
