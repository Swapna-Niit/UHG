package Sample;

public class BankAccount {
	String name;
	int amt;
	public float bal,rate;
	BankAccount(String a,float b){
		name=a;
		bal=b;
		rate=6;
	}
	void deposit(int amt){
		bal=amt+bal;
		
		
	}
	void withdraw(int amt){
		bal=bal-amt;
		
		}
	void viewbalance(int amt){
		System.out.println(bal);
		
		
	}

}
