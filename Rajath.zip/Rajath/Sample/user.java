package Sample;

public class user {

	public static void main(String[] args) {
		
		Credentials a=new Credentials("rajath",500000);
		Credentials b=new Credentials("ravi",500000);
		System.out.println(a.name);

		{
		
	}

}
}
