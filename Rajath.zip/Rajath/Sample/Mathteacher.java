package Sample;

public class Mathteacher extends Teachers {
	

}
