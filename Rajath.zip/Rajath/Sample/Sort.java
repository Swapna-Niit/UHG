package Sample;

import java.util.Scanner;

public class Sort {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int len;
		System.out.println("enter the array size");
		len=s.nextInt();
		int arr[]=new int[len];
		for(int i=0;i<len;i++){
			System.out.println("enter 1st array "+i+" element");
		    arr[i]=s.nextInt();
		}
		int i, key, j;
		   for (i = 1; i < len; i++)
		   {
		       key = arr[i];
		       j = i-1;
		 
		       
		       while (j >= 0 && arr[j] > key)
		       {
		           arr[j+1] = arr[j];
		           j = j-1;
		       }
		       arr[j+1] =key;
		   }
		   for(i=len-1;i>=0;i--){
				System.out.println(arr[i]);
			
			}

	}

}
