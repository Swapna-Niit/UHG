package Sample;

public class Odd {

	public static void main(String[] args) {
		int len=5,s=4,x=1;
	
		for(int i=0;i<len;i++){
			for(int j=0;j<s;j++){
				System.out.print(" ");
				
			}
			s--;
			for(int j=0;j<x;j++){
				System.out.print(x);
				
			}
			x=x+2;
			System.out.println("");
			
		
}
}}