package Sample;

 public class oddnum {

	public static void main(String[] args) {
	int num=1124;
	int num1=num;
	int rem,sum=0,m=1;
	while(num!=0){
		rem=num%10;
		sum=sum+rem;
		num=num/10;
	}
	
	System.out.println(sum);
	
	while(num1!=0)
	{
		rem=num1%10;
		m=m*rem;
		num1=num1/10;
}
	System.out.println(m);
	if(m==sum)
	System.out.println("spy number");
	else
		System.out.println("not");
	
}}