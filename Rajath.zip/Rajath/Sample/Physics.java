package Sample;

public class Physics extends Teachers  {

}
