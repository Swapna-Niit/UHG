package Sample;
import java.util.Scanner;

public class Neon {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the number");
		int num=s.nextInt();
		int num1=num*num;
		int rem,sum=0;
		while(num1!=0)
		{
			rem=num1%10;
			sum=sum+rem;
			num1=num1/10;
	}
		if(sum==num)
			System.out.println("neon");
		else
			System.out.println("not");
			

	}

}
