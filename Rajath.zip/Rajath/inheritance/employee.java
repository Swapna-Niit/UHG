package inheritance;

public class employee {
	static int empid=123;
	int sal=5;
	void readempid(){
		System.out.println(empid);
	}
	
	static void readsal(){
		System.out.println(empid);
	}
	
	
}
