package inheritance;


public class inheritance {
	
static int a=5;
static{
	 a=5;
}

}
