package inheritance;

	


public class check   {

	public static void main(String[] args) {
		inheritance abc=new inheritance();
		// TODO Auto-generated method 
	}

}
