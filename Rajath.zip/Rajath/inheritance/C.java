package inheritance;

public class C {

}
