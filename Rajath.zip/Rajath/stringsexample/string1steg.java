package stringsexample;
import java.util.Scanner;

public class string1steg {

	public static void main(String[] args) {
		String s="  game  ";
		String s2=new String();
		String s3=new String("rajath");
		System.out.println(s+s2+s3);
char[] str={'h','i'};
System.out.println(str);
System.out.println(s.indexOf('i'));
System.out.println(s.substring(0, 100));
Scanner sc= new Scanner(System.in);
System.out.println("enter");
s2="game";
s2=sc.nextLine();
System.out.println(s2);
System.out.println(s.hashCode());
s2="game";
System.out.println(s2.hashCode());
System.out.println(s);
System.out.println(s.trim().length());


	}

}
