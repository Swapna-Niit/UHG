package stringsexample;

import java.util.Arrays;

public class duplicate12 {

	public duplicate12() {
		// TODO Auto-generated constructor stub
	}
	static void  duplicate (char arr[])
	{ 
		Arrays.sort(arr);
		for(int x=0;x<arr.length-1;x++)
		{
			if (arr[x]==arr[x+1])
			{
				System.out.println("Duplicate");
				return;
			}
		}
        System.out.println("no duplicates");
	}
	public static void main(String args[])
	{
	String s1="Pentag122o";
	char str[]=s1.toCharArray();
	duplicate(str);
	}
}