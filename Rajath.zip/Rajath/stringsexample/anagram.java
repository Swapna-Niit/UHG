package stringsexample;
import java.util.StringTokenizer;
import java.util.Scanner;

public class anagram {
	
	
	static String sort(String str){
		String s1=str;
		char arr[]=s1.toCharArray();
		
		int len,key;
		   
		for (int i1 = 1; i1 < arr.length; i1++)
		   {
		       key = arr[i1];
		     int  j1 = i1-1;
		 
		       
		       while (j1 >= 0 && arr[j1] > key)
		       {
		           arr[j1+1] = arr[j1];
		           j1 = j1-1;
		       }
		       arr[j1+1] =(char) key;
		   }
		 //  for(int i=0;i<=arr.length-1;i++){
			//	System.out.print(arr[i]);
		//	
		//	}
		   String str1=new String(arr);
		   return str1;

		}

	public static void main(String[] args) {
		
		
		
		
		Scanner in = new Scanner(System.in);
		System.out.println("enter string");
		String s1 = in.nextLine();
		s1=s1.toLowerCase();
		System.out.println(s1);
		String[] arr=s1.split(" ");
		String a=sort(arr[0]);
		String b=sort(arr[1]);
		if(a.equals(b))
			System.out.println("anagram");
		else
			System.out.println("not");
		
		
		
		
		
	
		
		
		in.close();

	}

}

