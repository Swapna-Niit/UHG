package stringsexample;

public class duplicate {

	public static void main(String[] args) {
		String s="hello";
		int i=s.length();
		char str[]=s.toCharArray();
		
		

	}

}
