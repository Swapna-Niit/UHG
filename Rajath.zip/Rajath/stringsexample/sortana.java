package stringsexample;
import java.util.Scanner;

public class sortana {

	public static void main(String[] args) {
		
		String s1="the earth";
		char arr[]=s1.toCharArray();
		
		int len,key;
		   
		for (int i1 = 1; i1 < arr.length; i1++)
		   {
		       key = arr[i1];
		     int  j1 = i1-1;
		 
		       
		       while (j1 >= 0 && arr[j1] > key)
		       {
		           arr[j1+1] = arr[j1];
		           j1 = j1-1;
		       }
		       arr[j1+1] =(char) key;
		   }
		   for(int i=0;i<=arr.length-1;i++){
				System.out.print(arr[i]);
			
			}

	}


		
		// TODO Auto-generated method stub

	}


