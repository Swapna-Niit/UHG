package stringsexample;
import java.util.Scanner;
import java.util.StringJoiner;
public class regionmatch {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

		String s1="python programming123445";
		String s2="python Phythong12";
		boolean c=s1.regionMatches(true,0, s2, 7,1);
		System.out.println(c);
		
		
	}

}
