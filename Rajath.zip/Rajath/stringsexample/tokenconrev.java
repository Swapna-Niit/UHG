package stringsexample;
import java.util.StringTokenizer;



public class tokenconrev {

	public static void main(String[] args) {
		String s1,str;
		
String s="hello how r u";
StringBuffer sb=new StringBuffer();
StringTokenizer st=new StringTokenizer(s," ");

while(st.hasMoreTokens())
{
 s1=st.nextToken();

 StringBuffer sb1=new StringBuffer(s1);
 
 sb1.reverse();
 
 System.out.print(sb1);
// System.out.print(str);
 System.out.print(" ");
 


	}


}
}