package stringsexample;

public class dword {

	public static void main(String[] args) {
		
		String s="this is a string this";
		int flag=0;
		String arr[]=s.split(" ");
		//System.out.println("arr[i]");
		for(int i=0;i<arr.length-1;i++){
			for(int j=i+1;j<arr.length;j++){
				if(arr[i].equals(arr[j]))
				{	System.out.println("duplicate present ie.. "+arr[i]);
				flag=1;
				break;
				}
				
		
		
	}

}
		if(flag==0)
		System.out.println("not");
	}
}
