package stringsexample;

import java.util.StringTokenizer;
import java.util.Scanner;

public class rever {
	static void createToken(String str){
		StringTokenizer st = new StringTokenizer(str," ");
		
		
		while(st.hasMoreTokens()){
			//int size =  st.nextToken().length();
			int i;
			//System.out.println(st);
			//String ss = st.toString();
			char ch[] = st.nextToken().toCharArray();
			//for(i = 0;i<size;i++) System.out.println(ch[i]);
			int size = ch.length;
			for(i=size-1;i>=0;i--){
				System.out.print(ch[i]);
			}
			System.out.print(" ");
		}
	}
	public static void main(String[] str){
		Scanner in = new Scanner(System.in);
		System.out.println("enter string");
		String s1 = in.nextLine();
		createToken(s1);
		in.close();
		
	}

}

