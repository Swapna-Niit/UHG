import java.util.Scanner;

public class BitwiseOperator {
	Scanner s=new Scanner(System.in);
	int a,b;
	public void read()
	{
		System.out.println("enter the two numbers");
		 a=s.nextInt();
		 b=s.nextInt();
	}
	void bitand(){
		System.out.println("bit and of two no is"+(a&b));
	}
	void bitor(){
		System.out.println("bit or of two no is"+(a|b));
	}

	void bitxor(){
		System.out.println("bit xor of two no is"+(a^b));
	}
	void bitothers(){
		System.out.println("bit right no is"+(a>>b));
		System.out.println("bit left no is"+(a<<b));
		System.out.println("bit and equal no is"+(a&=b));
		System.out.println("bit and of two no is"+(a>>=b));
		System.out.println("bit and of two no is"+(a));
		System.out.println("bit and of two no is"+(~a));
	}


}
