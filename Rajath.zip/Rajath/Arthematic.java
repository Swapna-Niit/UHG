
public class Arthematic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addition ad=new Addition();
		int a=0;
		ad.add(4,5);
	
		


	}

}
