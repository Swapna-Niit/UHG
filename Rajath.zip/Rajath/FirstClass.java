import java.util.Scanner;
public class FirstClass {
public static void main(String[] str)
{
	Scanner s=new Scanner(System.in);
	int len;
	System.out.println("enter the array size");
	len=s.nextInt();
	char arr[]=new char[len];
	for(int i=0;i<len;i++){
		System.out.println("enter 1st array "+i+" element");
	 arr[i]=s.next().charAt(0);
	}
	for(int i=len-1;i>=0;i--){
		System.out.println(arr[i]);
	
	}
	for(int i=0;i<len-2;i++){
		for(int j=i+1;j<len;j++){
			if(arr[i]==arr[j])
			{	System.out.println("duplicate present ie.. "+arr[i]);
			break;
			}
			
		}
		
		
	}
	
}
}