package pack;


public class Employee {
	 int eid;
	 String ename;
	 float sal;
	  Employee(int id,String name,float sa)
	  {
		   eid=id;
		   ename=name;
		  sal=sa;
	  }
	  public void display()
		{
			System.out.println(eid + ename + sal);
		}

}