package pack;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				Employee arr1[]= new Employee[2];
				Department arr2[]=new Department[1];
		//Department arr2=new Department();
				
				arr1[0]= new Employee(100,"Raj",10000f);
				arr1[1]= new Employee(101,"Ram",15000f);
				arr2[0]= new Department(1,"Maths");
				arr1[0].display();
				arr1[1].display();
				arr2[0].display();

	}
	
}
