package pack;

public class Marks {

}
