package pack;
import java.util.*;
public class Department {
	Scanner sc=new Scanner(System.in);
	int did;
	String dname;
	Department(int id,String name)
	{
		did=id;
		 dname=name;
	}
	public void display()
	{
		System.out.println(did + dname);
	}

}
