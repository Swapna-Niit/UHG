package pack;

public class Result {

}
