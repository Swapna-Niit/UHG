import java.util.Scanner;
/**
 * author:rajath
 * @author Trainee Staff
 *
 */
public class Addition {
	Scanner s=new Scanner(System.in);
	int a,b;
	/*public void read(int x, int y)
	{
		System.out.println("enter the two numbers");
		 a=x;
		 b=y;
	}
	*/
	public void add(int x, int y)
	{//add two number
		System.out.println("sum of two number is "+(x+y));
	}
	
}
