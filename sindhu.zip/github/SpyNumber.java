package sample;

import java.util.Scanner;

public class SpyNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number:");
		int num = sc.nextInt();
		int temp=num,sum=0, product=1;
		while(num!=0)
		{
			temp=num%10;
			sum=sum+temp;
			product=product*temp;
			num=num/10;
		}
		if(sum==product)
		{
			System.out.println("The number is a spy number");
		}
		else
			System.out.println("The number is not a spy number");

	}

}
