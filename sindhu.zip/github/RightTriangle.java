package sample;

import java.util.Scanner;

public class RightTriangle {
	public static void main(String[] arg)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the 3 angles");
		int fir, sec, third;
		fir = sc.nextInt();
		sec = sc.nextInt();
		third = sc.nextInt();
		if(fir==90 || sec ==90 || third==90 )
		{
			
		
				System.out.println("The triangle is right angled");
			}
				else
					System.out.println("The triangle is not right angled");
		}
			
	}


