package sample;

import java.util.Scanner;

public class Osubtraction {
	/** Name : Sindhu
	 *  Class : Subtraction of two numbers
	 */
	Scanner sc = new Scanner(System.in);
	int firval, secval;
	/**
	 * reading the two values
	 */
	public void read()//method definition
	{
		
		System.out.println("Enter First Value:");
		firval = sc.nextInt();
		System.out.println("Enter Second Value:");
		secval = sc.nextInt();
		
	}
	/**
	 * subtracting two values read from the keyboard
	 */
	public void sub()
	{
		
		System.out.println("Difference of two values is"+(firval-secval));
	}

}
