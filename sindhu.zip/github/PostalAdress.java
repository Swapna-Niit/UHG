package multipleinheritance;

public interface PostalAdress extends Address,City{
	void readPostalAddress();

}
