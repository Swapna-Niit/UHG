package multipleinheritance;

import java.util.Scanner;

public class Student {
	protected String name = new String();
	Scanner sc = new Scanner(System.in);
	protected int id;
	void read(){
		System.out.println("Enter name, id, marks and subject of the student");
		name = sc.next();
		id = sc.nextInt();
		
		
	}
	

}
