package sample;

public class DataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long l=784584255l;
		System.out.println(78+852+654.2585685+878556667);
		System.out.println('A'+25);
		int i;//declaration
		float f=8275.284f;
		double d=-58754.5647;
		char ch='S';
		short s=5248;
		byte b=127;
		boolean bl=true;

		i=7;
		System.out.println(bl);
		System.out.println(l);
		System.out.println(i);
		System.out.println(ch);
		System.out.println("the value of character is" +s);
		System.out.println(b);
		System.out.println(d);
		System.out.println("boolean value is " +bl);
	}

}
