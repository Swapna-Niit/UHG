package sample;

import java.util.Scanner;

public class Triangle extends Shape {
	Triangle()
	{
		System.out.println("triangle constructor");
	}
	Scanner sc = new Scanner(System.in);
	float l,b,h;
	void readLength()
	{
		
		l= sc.nextInt();
	}
	void readBreadth()
	{
		
		b=sc.nextInt();
	}
	void readHeight()
	{
		
		h=sc.nextInt();
	}
	protected void countCorners()
	{
		System.out.println("3 corners");
	}
	void area()
	{
		System.out.println(" triangle"+(0.5*b*h));
	}
	
}
