
package sample;
import java.util.Scanner;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Array declaration
		int a[]= new int[5];
		char c[]= {'a','b','c'};
		System.out.println(a.length);
		System.out.println(c.length);
		System.out.println(a);
		System.out.println(c);
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two values");
		int aval = sc.nextInt();
		int sval = sc.nextInt();
		
		System.out.println("sum of two number is "+ (aval+sval));
		sc.close();
	}

}
