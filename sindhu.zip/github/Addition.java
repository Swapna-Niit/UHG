package sample;

public class Addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		int a=10;
		int b=3;
		System.out.print("Sum="+(a+b));
		System.out.print(String.format("Sum of a and b is %d", a+b));
	}

}
