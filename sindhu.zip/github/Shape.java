package sample;

import java.util.Scanner;

public class Shape {
	Shape(){
		System.out.println("In shape class");
	}
void readLength()
{
	System.out.println("Length of shape");
	
}
void readBreadth()
{
	System.out.println("Breadth of shape");
	
}
void readHeight()
{
	System.out.println("Height of shape");
	
}
void countCorners()
{
	System.out.println("unpredictable");
}
void area()
{
	System.out.println("Area of shape");
	
}
void perimeter()
{
	System.out.println("Perimeter of shape");
}
}
