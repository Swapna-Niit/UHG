package sample;

public class Oadditionmain {
	public static void main(String[] args)
	{
		Oaddition ad = new Oaddition();
		ad.read();//method calling
		ad.firval = 10;
		ad.secval = 6;
		
		ad.add();
	}

}
