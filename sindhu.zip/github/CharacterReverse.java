package sample;
import java.util.Scanner;


public class CharacterReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arsize;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the word:");
		arsize=sc.nextInt();
		int sum=0;
		
		
		char ch[] = new char[arsize];
		
		System.out.println("Enter the word:");
		for(int i=0; i<arsize; i++)
			{
				ch[i]=sc.next().charAt(0);
				sum=sum+ch[i];
			}
		for(int j=arsize-1; j>=0; j--)
		{
			System.out.println("The array is "+ch[j]);
		}
		System.out.println("The sum of characters in array is "+sum);
	}

}
