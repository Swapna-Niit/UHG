package sample;
import java.util.Scanner;

public class AddArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int a[]= new int[5];
		int sum=0;
		System.out.println("Enter the 5 array elements:");
		for(int i=0; i<5; i++){
			a[i]=sc.nextInt();	
			sum=sum+a[i];
		}
		System.out.println("The sum of array elements is: "+sum);
		
	}

}
