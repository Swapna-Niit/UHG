package sample;

import java.util.Scanner;

public class Oaddition {
	/** Name : Sindhu
	 *  Class : Addition of two numbers
	 */
	Scanner sc = new Scanner(System.in);
	int firval, secval;
	/**
	 * reading the two values
	 */
	public void read()//method definition
	{
		
		System.out.println("Enter First Value:");
		firval = sc.nextInt();
		System.out.println("Enter Second Value:");
		secval = sc.nextInt();
		
	}
	/**
	 * adding two values read from the keyboard
	 */
	public void add()
	{
		
		System.out.println("Sum of two values is"+(firval+secval));
	}
}
