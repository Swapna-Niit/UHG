package sample;

import java.util.Scanner;

public class SizeArray {
public static void main(String[] args)
{
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the size of the array");
	
	int asize = sc.nextInt();
	int arr[] = new int[asize];
	for(int i=asize-1; i>=0;  i--)
	{
	System.out.println("enter the  "+i+ "th element");
	arr[i]=sc.nextInt();
	}
}


}

