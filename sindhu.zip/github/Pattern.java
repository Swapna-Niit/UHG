package sample;

public class Pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k=5;
		for(i=5; i>0; i--)
		{
			 
			for(j=k;j>0; j--)
			{
				System.out.print("*");
				
			}
			System.out.println("\n");
			k--;

	}
		k=1;
		for(i=0; i<5; i++)
		{
			for(j=0; j<k; j++)
			{
				System.out.print("*");
			}
			System.out.println("\n");
			k++;	
		}
	}
}
