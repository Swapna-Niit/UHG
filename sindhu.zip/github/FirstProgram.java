package sample;


class FirstProgram
{
	public static void main(String[] str)
	{
		System.out.print("this is my first program");
	}
}