package stringsprograms;

public class StringJoinMEt {

	public static void main(String...str)
	{
		String s = "Python";
		String s1 = "Python Program";
		System.out.println(String.join(s1,s1,"Langauage"));
	}
}
