package multipleinheritance;

public interface City {

	void readCity();
}
