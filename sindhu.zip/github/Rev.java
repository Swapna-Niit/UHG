package stringsprograms;

import java.util.Scanner;


public class Rev {

	public char[] sort(String a){
			int i,j;
			char cha[]= a.toCharArray();
			int n= a.length();
			char temp='\0';
			for(i = 0; i < n; i++)
		    {
		        for(j = 0; j < n-i-1; j++)
		        {
		            if( cha[j] > cha[j+1])
		            {
		                // swap the elements
		                temp = cha[j];
		                cha[j] = cha[j+1];
		                cha[j+1] = temp;
		            } 
		        }
		    }
			return cha;
	}
	
	
				
	
}
