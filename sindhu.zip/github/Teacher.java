package sample;

public class Teacher {
	Teacher()
	{
		System.out.println("Good morning students");
	}
	public int teacherid;
	public float salary;
	
	void teaches(){
		System.out.println("Teacher teaches the subject");
	}

}
