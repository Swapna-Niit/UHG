package sample;

import java.util.Scanner;

public class Square extends Triangle 
{
	Square()
	{
		System.out.println("square constructor");
	}
	Scanner sc = new Scanner(System.in);
	Square(float len)
	{
		l=len;
	
	}
	void area()
	{
		System.out.println("Area is"+(l*l));
	}
	
	

}
