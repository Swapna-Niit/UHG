package sample;

public class English extends Teacher {
	English(int id, float sal)
	{
		teacherid=id;
		salary=sal;
		System.out.println("Shakespeare is a great writer");
	}
	void teaches()
	{
		System.out.println("English teacher teaches communication");
	}
	
		void print()
		{
			System.out.println("Teacher id and Salary of english teacher are"+teacherid+salary);
		}
	
}
