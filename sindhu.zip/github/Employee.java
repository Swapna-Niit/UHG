package multipleinheritance;

public class Employee {
	int id;
	String name[]= new String[25];
	float sal;
	Employee(int id, String name, float sal){
		System.out.println("Employee id is "+id+"\tEmployee name is "+name+"\tEmployee salary is "+sal);
	}
	

}
