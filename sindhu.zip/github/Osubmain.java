package sample;

public class Osubmain {
	public static void main(String[] args)
	{
		Osubtraction ad = new Osubtraction();
		ad.read();//method calling
	
		
		ad.sub();
	}

}
