package sample;

public class MainTeacher{
	public static void main(String[] arg){

	English en=new English(1,20000.00f);
	Computer cs=new Computer(2,25000.00f);
	en.teaches();
	en.print();
	cs.teaches();
	cs.print();
	}
	
}
