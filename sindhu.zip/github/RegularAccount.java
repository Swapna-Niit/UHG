package sample;

public class RegularAccount {

}
