package sample;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(3.5%2.6);
		int i;
		System.out.println(2*3/4+4/4+8-2+5/8);
		System.out.println(3/2*4+3/8+3);
		int a=20,b=1,c=3,d=4,g=5,v=6,x=7,y=79,q=1,r=5,l=8,m=1;
		long Z,X,R,A;
		Z=(long) ((8.8*(a+b)*2/c-0.5+2*a/(q+r))/(a+b)*(l/m));
		X=(long)(-b+(b*b)+24*a*c)/(2*a);
		R=(long) ((2*v+6.22*(c+d))/(g+v));
		A=(long) ((7.7*b*(x*y+a)/c-0.8+2*b)/(x+a)*(1/y));
		System.out.println(X);
		System.out.println(Z);
		System.out.println(R);
		System.out.println(A);
	}

}
