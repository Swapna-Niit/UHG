package stringsprograms;

public class ValueOfMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

String strValue = "Python";
char[] values = strValue.toCharArray();
for(char c:values)
{
	System.out.println(String.valueOf(c));
}
}

}
