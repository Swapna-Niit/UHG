package sample;

import java.util.Scanner;

public class AutomorphicNumber {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number:");
		int num = sc.nextInt();
		int sq=0;
		sq=num*num;
		int temp;
		int numr=num%10;
		temp=sq%10;
		if(numr==temp)
		{
			System.out.println("The number is an automorphic number");
		
		}
		else
			System.out.println("The number is not an automorphic number");

	}

}
