package sample;

import java.util.Scanner;

public class DupCharacter {

	public static void main(String[] args) {
		int size;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array of characters");
	    size = sc.nextInt();
		System.out.println("Enter an array of characters");
		char arr[] = new char[size];
		for(int i=0; i<size; i++){
			arr[i] = sc.next().charAt(0);
			
		}
		char arrd[] = new char[size];
		char m='\0';

		int count=0;
		for(int l=0; l<size; l++)
		{
		    m=arr[l];
		    for(int j=l+1; j<size; j++)
		    {
			if(m==arr[l+1])
			{
				//dup[l]=(l+1);
				
				count++;
				
			}
			m++;
			}
		
		   
		   
			
		}
		

	}

}
