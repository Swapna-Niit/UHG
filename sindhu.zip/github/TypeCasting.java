package sample;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Implicit type conversion
		int a;
		short s=20;
		a=s;
		
		float f=30.343567f;
		double d;
		d=f;
		
		d=a;
		
		//Explicit type conversion or narrowing
		float fl =30.3435874f;
		a=(int)fl;
		s=(short)f;
		System.out.println(s);
		System.out.println(s);
		System.out.println(a);

		
		

	}

}
