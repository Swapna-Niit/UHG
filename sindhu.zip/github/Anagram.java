package stringsprograms;

public class Anagram {
	 void bubbleSort(String[] array) {  
	        int n = array.length;  
	        String temp;
	        
	                // Begin For loop
	        
	                for(int i=0; i<array.length; i++) {
	        
	                    //Open For loop
	        
	                    for(int j=0; j<array.length-1-i; j++) {
	        
	                        //Open If Statement Compare and sort strings
	        
	                    if(array[j].compareTo(array[j+1])>0) {
	        
	                        temp = array[j];
	        
	                        array[j] = array[j+1];
	        
	                        array[j+1] = temp;

	                 }  
	                    for(i=0; i<n;i++){
	                    	System.out.println(array[i]);
	                    }

}
	 }
	 }
}
