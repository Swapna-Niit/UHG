package sample;

public class Polygon extends Shape{
	void countCorners()
	{
		System.out.println("unpredictable");
	}

}
