package stringsprograms;

import java.util.Scanner;

public class RevMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rev r = new Rev();
		Scanner sc = new Scanner(System.in);
		String s1 = sc.nextLine().toLowerCase();
		String s2 = sc.nextLine().toLowerCase();
		
		char[] ch1 = r.sort(s1);
		char[] ch2 = r.sort(s2);
		String k = String.valueOf(ch1);
		String l = String.valueOf(ch2);
		if(k.equals(l))
		{
			System.out.println("Strings are equal");
		}
		else
			{
			System.out.println("Strings are not equal");
			}

}
}