package stringsprograms;

import java.util.Scanner;

public class DuplicateCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = new String();
		Scanner sc = new Scanner(System.in);
		s = sc.nextLine();
		int count=0;
		String arr[] =s.split(" ");
	   String temp; 
		for(int i=0; i<arr.length; i++)
		{
			temp=arr[i];
			for(int j=i+1; j<arr.length; j++)
			{
				if(temp==s[j])
				{
					
					count++;
				}
				
			}
			System.out.println("The word" + temp + "is repeated count times" + count);
		}
	}
}
				
		
		
	
