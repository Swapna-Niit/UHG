package stringsprograms;

public class MainReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//ReverseToken r = new ReverseToken("This is java programming Class");
		//r.read();
		//r.print();
		ReverseToken s = new ReverseToken();
		String a = "This is java programming";
		
			s.read(a);
			
			
			// TODO Auto-generated method stub

	
		
	}

}
