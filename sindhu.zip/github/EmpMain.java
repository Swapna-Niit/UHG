package multipleinheritance;

public class EmpMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp[]= new Employee[5];
		emp[0] = new Employee(123, "rama", 123.456f);
		emp[1] = new Employee(234, "raja", 533.456f);
		Department d[] = new Department[3];
		d[0]= new Department(12,"Accounts");

	}

}
