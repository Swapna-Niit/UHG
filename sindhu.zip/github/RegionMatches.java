package stringsprograms;
import java.util.StringJoiner;
import java.util.StringTokenizer;
public class RegionMatches {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*String s = "HEllo folks HI";
		String st = "HI";
		String a = "HEllo folks HI";
		String b = "HI";
		String m = "hello hi";
		boolean c = a.regionMatches(true,0, m, 0,4);
		//System.out.println(s.length());
		//System.out.println(st.length());
		//System.out.println(st.substring(6));
		
		System.out.println(c);
		StringBuffer sb = new StringBuffer(s);
		sb.append("This is immutable");
		System.out.println(sb);
		String str = sb.toString();
		sb.setLength(10);
		System.out.println(sb.capacity());
		System.out.println(sb.length());
		System.out.println(str);
		System.out.println(sb.insert(5, true));
		System.out.println(sb.capacity());
		sb.ensureCapacity(25);
		System.out.println(sb.capacity());
		sb.setCharAt(0, 'B');
		System.out.println(sb.toString());
		char [] arr = new char[30];
		sb.getChars(6, 12, arr, 6);
		System.out.println(arr);
		//String strrev = sb.reverse().toString();
		//System.out.println(strrev);
		StringBuffer strrep = sb.replace(7, 11, "Java");
		System.out.println(strrep);
		StringBuilder sbl = new StringBuilder(m);
		String l = m;
		System.out.println(l);
		String x = "This is a Java String";
		StringTokenizer stri = new StringTokenizer(x,"-");
		System.out.println(stri);
		while(stri.hasMoreTokens())
		{
			//System.out.print(stri.nextToken(","));
			if(stri.nextToken().equals("Java"))
			System.out.println("tokens exists");
			else 
				System.out.println("no tokens");
		}*/
		
		String ab = "Hello world";
		StringJoiner sj = new StringJoiner(" ");
		sj.add("this");
		sj.add("is");
		sj.add("boring");
		System.out.println(sj);
		sj.toString();
		StringJoiner sj1 = new StringJoiner("/");
		sj1.add("2018");
		sj1.add("7");
		sj1.add("23");
		System.out.println(sj1);
		sj1.toString();
 	}
	

}
