package stringsprograms;

import java.util.StringTokenizer;

public class Anag {
	String str;
	String rev = "";
	
	void read(){
		StringTokenizer st = new StringTokenizer(str," ");
				while(st.hasMoreTokens())
			{
				//System.out.println(st.nextToken());
				char arr[] = st.nextToken().toCharArray();
				int size = arr.length;
				for(int i=size-1;i>=0;i--){
					System.out.print(arr[i]);
				}
				System.out.println("\t");
			}
				
	}

	

}
