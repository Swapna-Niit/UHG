package sample;

import java.util.Scanner;

public class Bit_Operator {
	Scanner sc = new Scanner(System.in);
	int val1, val2;
	void read()
	{
		System.out.println("Enter two values");
		val1 = sc.nextInt();
		val2 = sc.nextInt();
	}
	void bitAnd()
	{
		System.out.println("Bitwise and operation result is: "+(val1&val2));
		
	}
	
	void bitOr()
	{
		System.out.println("Bitwise or operation result is: "+(val1|val2));
		
	}
	
	void bitexor()
	{
		System.out.println("Bitwise exor operation result is: "+(val1^val2));
		
	}
	void bitorassign()
	{
		System.out.println("Bitwise or assignment operation result is: "+(val1|=val2));
		
	}
	void bitAndassign()
	{
		System.out.println("Bitwise And assignment operation result is: "+(val1&=val2));
		
	}
	void bitshiftright()
	{
		System.out.println("Bitwise right shift operation result is: "+(val1>>2));
		
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bit_Operator op= new Bit_Operator();
		op.read();
		op.bitAnd();
		op.bitOr();
		op.bitAndassign();
		
		op.bitexor();
		op.bitorassign();
		op.bitshiftright();
		
	}

}
