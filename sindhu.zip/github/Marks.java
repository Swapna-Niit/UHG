package multipleinheritance;

import java.util.Scanner;

public class Marks extends Student {
	public String subject =new String();
	Scanner sc = new Scanner(System.in);
	protected int marks;
	void marksentry()
	{
		super.read();
		marks = sc.nextInt();
		subject = sc.next();
		
		
	}
	void cal()
	{
		
		System.out.println("Student "+super.name + " with id " + super.id + " has scored " + marks + " in subject " +subject );
	}

}
