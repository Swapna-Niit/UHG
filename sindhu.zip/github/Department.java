package multipleinheritance;

public class Department {

	int did;
	String dname[] = new String[20];
	Department(int did, String dname){
		System.out.println("Department id is "+did+"\t Department name is "+dname);
	}
	
}
