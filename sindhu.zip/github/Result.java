package multipleinheritance;

public class Result extends Marks {
	private char grade;

	void print()
	{
		super.marksentry();
		super.cal();
		if(super.marks>40){
			this.grade ='P';
		System.out.println("Student has passed with grade "+grade);
		}
		else
		{
			this.grade = 'F';
					System.out.println("Student has failed with grade "+grade);
		}
			
	}
	
	

}
