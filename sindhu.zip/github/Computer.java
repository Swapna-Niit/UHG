package sample;

public class Computer extends Teacher{
	Computer(int idc, float salry)
	{
		teacherid=idc;
		salary=salry;
		System.out.println("Java is useful");
	}
	void teaches()
	{
		System.out.println("Computer teaches Java");
	}
	void print()
	{
		System.out.println("Teacher id and Salary of computer teacher are"+teacherid+salary);
	}

}
