
public class Teacher 
{
	void Teacher()
	{
		System.out.println("Teacher");
	}
	
	void teaches()//method
	{
		System.out.println("Subject");
	}
}
