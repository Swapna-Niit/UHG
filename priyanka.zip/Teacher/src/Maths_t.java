
public class Maths_t extends Teacher
{
	void T_id()//method
	{
		System.out.println("ID of teacher= M");
	}
	
	void T_salary()//method
	{
		System.out.println("Salary of teacher= 7k");
	}
}
