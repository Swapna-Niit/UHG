
public class TMain 
{
	public static void main(String[] args) 
	{
		Teacher t= new Teacher();
		t.teaches();
		
		Maths_t m=new Maths_t();
		m.T_id();
		m.T_salary();
		
		Chem_t c=new Chem_t();
		c.T_id();
		c.T_salary();
	}
}
