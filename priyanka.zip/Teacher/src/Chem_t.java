
public class Chem_t 
{
	void T_id()//method
	{
		System.out.println("ID of teacher= C");
	}
	
	void T_salary()//method
	{
		System.out.println("Salary of teacher= 9k");
	}
}
