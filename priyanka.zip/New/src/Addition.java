import java.util.Scanner;

public class Addition 
{
	Scanner sc=new Scanner(System.in);
    int fval;//class variable or instance variable
    int sval;//class variable or instance variable
	public void read() 
	{
		/**
		 * addition of values
		 */
		System.out.println("Enter first value");
		fval=sc.nextInt();
		System.out.println("Enter second value");
		sval=sc.nextInt();
		
	}
	
	public void add()
	{
		System.out.println("Addition of two values is "+(fval+sval));
	}

}
