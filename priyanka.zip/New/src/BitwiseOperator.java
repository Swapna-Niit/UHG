import java.util.Scanner;
public class BitwiseOperator 
{
	
	int AND(int val1,int val2)
	{
		//System.out.println("AND--" + (val1&val2));
		return(val1,val2);
	}
	
	int OR(int val1,int val2)
	{
		//System.out.println("OR--" + (val1|val2));
		return(val1,val2);
	}
	

	}
	
	/*public void NOT()
	{
		System.out.println("NOT--" + (~val2));

	}
	
	public void XOR()
	{
		System.out.println("XOR--" + (val1^val2));

	}
	
	public void SR()
	{
		System.out.println("SR--" + (val1>>val2));

	}
	
	public void SRZ()
	{
		System.out.println("SRZ--" + (val1>>>val2));

	}
	
	public void SL()
	{
		System.out.println("SL--" + (val1<<val2));

	}
	
	public void ANDass()
	{
		System.out.println("ANDass--" + (val1&=val2));

	}
	
	public void ORass()
	{
		System.out.println("ORass--" + (val1|=val2));

	}
	
	public void XORass()
	{
		System.out.println("XORass--" + (val1^=val2));

	}
	
	public void SRass()
	{
		System.out.println("SRass--" + (val1>>=val2));

	}
	
	public void SRZass()
	{
		System.out.println("SRZass--" + (val1>>>=val2));

	}
	
	public void SLass()
	{
		System.out.println("SLass--" + (val1<<=val2));

	}*/

}
