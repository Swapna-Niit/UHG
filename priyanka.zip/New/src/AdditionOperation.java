import java.util.Scanner;

public class AdditionOperation
{
	Scanner sc=new Scanner(System.in);
	int val1,val2;
	void read()
	{
		System.out.println("Enter two values");
		val1=sc.nextInt();
		val2=sc.nextInt();
	}


	public static void main(String[] args) 
	{
		/*Addition ad=new Addition();
		ad.read();
		ad.fval=9;
		ad.sval=8;
		ad.add();*/
		BitwiseOperator bo=new BitwiseOperator();
		bo.OR(bo.val1,bo.val2);
		bo.AND(bo.val1,bo.val2);
		
		

	}

}
