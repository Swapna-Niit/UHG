import java.util.Scanner;

public class DataTyp {
 public static void main(String[] args)
 {
	 //scanner is a predefined class in java to read the data from keyboard
	//Scanner sc = new Scanner(System.in);
	System.out.println("enter the choice");
	System.out.println("alphabets");
	System.out.println("numbvers");
	Scanner sc = new Scanner(System.in);
	char ch=sc.next().charAt(0);
	String ch =sc.next();
	switch(ch)
	{
	case
	}
 }
}
