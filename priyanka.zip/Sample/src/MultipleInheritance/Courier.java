package MultipleInheritance;

public class Courier implements PostalAddress {

	public static void main(String[] args) 
	{
		

	}

	@Override
	public void readAddress() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readCity() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void connectDB() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readPostalAddress() {
		// TODO Auto-generated method stub
		
	}

}
