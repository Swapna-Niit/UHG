package MultipleInheritance;

public interface Address 
{
	void readAddress();
	
		
	
}
