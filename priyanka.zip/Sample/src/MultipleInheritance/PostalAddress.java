package MultipleInheritance;

import interfaceDemo.DataBase;
public interface PostalAddress extends Address,City,DataBase
{
	void readPostalAddress();
}
