package MultipleInheritance;

public interface City 
{
	void readCity();
}
