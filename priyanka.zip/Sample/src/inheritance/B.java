package inheritance;

public class B extends A
{
	void printInfo()
	{
		System.out.println("B class method");
		super.printInfo();
	}
}
