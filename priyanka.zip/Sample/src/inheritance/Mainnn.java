package inheritance;

public class Mainnn {

	
	public static void main(String...st) 
	{
		C c=new C();
		c.printInfo("Rama",56);
	}

}
