package inheritance;

public class C extends B
{
	void printInfo()
	{
		System.out.println("C class method");
		super.printInfo();
	}
}
