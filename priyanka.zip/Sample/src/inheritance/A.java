package inheritance;

public class A 
{
	void printInfo()
	{
		System.out.println("A class method");
	}
	
	void printInfo(String s,int i)
	{
		this.printInfo();
		System.out.println("String method=/t" + s + "/t" + i);
	}
}
