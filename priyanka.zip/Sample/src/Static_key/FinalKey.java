package Static_key;

public class FinalKey 
{
	final float pi=3.141414f;
	public void method()
	{
		
	}
}
