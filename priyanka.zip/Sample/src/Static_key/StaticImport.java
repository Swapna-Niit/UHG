package Static_key;
import static java.lang.Integer.MAX_VALUE;
import static java.lang.Integer.MIN_VALUE;
public class StaticImport
{
	public static void main(String[] args)
	{
		System.out.println("max value of interger= " + Integer.MAX_VALUE);
		System.out.println("max value of interger= " + Integer.MIN_VALUE);
	}
}
