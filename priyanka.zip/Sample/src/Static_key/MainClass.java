package Static_key;

public class MainClass {

	public static void main(String[] args) 
	{
		Vehicle v=new Car();
		System.out.println(v instanceof Car);
		System.out.println(v instanceof Vehicle);
		
		v.kmToMiles(500);

	}

}
