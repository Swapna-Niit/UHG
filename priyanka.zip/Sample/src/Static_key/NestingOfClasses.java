package Static_key;

public class NestingOfClasses 
{
	public static class Outer
	{
		public void ex()
		{
			System.out.println("this is outer class");
		}
	
	public class Inner//inner class which can be static
	{
		public void ex()
		{
			System.out.println("this is inner class");
		}
	}
	
	public static void main(String[] args) 
	{
		//Outer.Inner ee=new Outer.Inner();
		//ee.ex();
		//Outer.Inner ioc;
		//ioc=new Inner();
		Outer oc=new Outer();
		Outer.Inner o=oc.new Inner();
		o.ex();

	}
	}

}
