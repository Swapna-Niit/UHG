package Static_key;

public class Car extends Vehicle
{
	public void kmToMiles(int km)
	{
		System.out.println("inside child class");
	}
}
