package Static_key;

public class Vehicle 
{
	public void kmToMiles(int km)
	{
		System.out.println("inside parent class");
	}
}
