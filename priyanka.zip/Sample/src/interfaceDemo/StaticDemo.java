package interfaceDemo;

public class StaticDemo {
static
{
	System.out.println("inside static block");
}

public static void main(String[] as)
{
	StaticDemo ss= new StaticDemo();
}
}
