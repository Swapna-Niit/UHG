package interfaceDemo;

public class InterfaceMainClass {

	public static void main(String[] args) 
	{
		DataBaseIm dbi=new DataBaseIm();
		dbi.ConnectionValues();//calling dynamic method
		dbi.connectDB();
		DataBase.values();//calling static method
	}

}
