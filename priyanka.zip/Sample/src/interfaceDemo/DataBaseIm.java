package interfaceDemo;

public class DataBaseIm implements DataBase
{
	//interface upto java 7 does not allow any implementation of the code

	@Override
	public void connectDB() 
	{
		// TODO Auto-generated method stub
		System.out.println("connection to DB");
	}
}
