package interfaceDemo;

public interface DataBase 
{
	int a=30;
	
	void connectDB();
	//java 8 features
	default void ConnectionValues()
	{
		System.out.println("reads the DB url and name " + "and pwd");
	}
	
	static void values()
	{
		System.out.println("reads the DB url and name " + "and pwd");
	}
}
