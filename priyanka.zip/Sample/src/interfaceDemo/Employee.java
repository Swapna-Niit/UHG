package interfaceDemo;

public class Employee 
{
	static int empid=123;
	int sal=9000;
	void readEmpid()
	{
		System.out.println("empid");
	}//static values can be used in nonstatic
	
	static void readEmpname()
	{
		//System.out.println("sal");
	}//non-static values cannot be used in static
	
	public static void main(String[] args)
	{
		Employee e=new Employee();
		e.readEmpid();
	}
}
