import java.util.Scanner;
public class Shapes 
{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value of n----");
		int n=sc.nextInt();
		for(int i=1;i<=n;i++)
		{
			for(int k=0;k<(2*i-1);k++)
				System.out.print(" ");
			for(int j=0;j<(2*i-1);j++)
				System.out.print(2*i-1);
			System.out.println();
		}
		
	}

}
