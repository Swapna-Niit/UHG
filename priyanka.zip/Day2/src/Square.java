import java.util.Scanner;


public class Square extends Triangle {

	//sq extends shape so shape is uperclass and sq is subclass

	/*Square()
	{
		System.out.println("square constructor");
	}*/
	
	Square()
	{
		System.out.println("in s constructor");
	}//default or unparameterised constructor
	
	Square(int len)
	{
		this();//calling the above unparameterised constructor using this keyword
		l=len;
	}//parameterised constructor
		Scanner sc= new Scanner(System.in);
		
		
		protected void CountCorners()
		{
			System.out.println("Corners of shape=4");
		}
		
		void area()
		{
			System.out.println("area of shape= " + (l*l));
		}
		


}
