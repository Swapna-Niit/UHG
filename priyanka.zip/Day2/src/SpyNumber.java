import java.util.Scanner;

public class SpyNumber 
{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value of n----");
		int n=sc.nextInt();
		int a=0,b=1,c=0,d=1;
		int nn=n,count=0;
		while(nn!=0)
		{
			nn=nn/10;
			count++;
		}
		int n1=n;
		for(int i=0;i<count;i++)
		{
			c=n1%10;
			a=a+c;
			n1=n1/10;
		}
		System.out.println("the value of a----" + a);
		int n2=n;
		for(int j=0;j<count;j++)
		{
			d=n2%10;
			b=b*d;
			n2=n2/10;
		}
		System.out.println("the value of b----" + b);
		
		if(a==b)
		{
			System.out.println("the number is a spy number");
		}
	}
}