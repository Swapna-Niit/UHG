
public class SHAPE 
{

	//constructor for shape
	SHAPE()
	{
		System.out.println("shape");
	}
	void area()
	{
		System.out.println("ARea of shape");
	}
	
	void length()
	{
		System.out.println("length of shape");
	}
	
	void breadth()
	{
		System.out.println("breadth of shape");
	}
	
	void perimeter()
	{
		System.out.println("perimeter of shape");
	}
	
	void CountCorners()
	{
		System.out.println("Corners of shape");
	}

}
