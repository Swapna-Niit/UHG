
public class Main {

	public static void main(String[] args) 
	{
		/*Triangle t= new Triangle();
		t.length();
		t.height();
		t.breadth();
		t.area();
		*/
		Square s= new Square(50);
		s.area();

	}

}
