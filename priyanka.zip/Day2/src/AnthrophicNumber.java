import java.util.Scanner;

public class AnthrophicNumber 
{

	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value of n----");
		int n=sc.nextInt();
		int nn = n*n,s=n,count=0,n2,n3;
		while(s!=0)
		{
			s=s/10;
			count++;
		}
		
		n2=n%10;
		
		n3=nn%10;
		
		if(n2==n3)
		{
			System.out.println("the number is automorphic");
		}
		else
		{
			System.out.println("the number is not automorphic");
		}
	}

}
