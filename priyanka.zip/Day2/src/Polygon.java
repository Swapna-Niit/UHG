
public class Polygon extends Square
{
	Polygon(int len) {
		super(len);
		// TODO Auto-generated constructor stub
	}

	protected void CountCorners()
	{
		System.out.println("Corners of shape=4");
	}
}
