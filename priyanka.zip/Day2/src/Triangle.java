import java.util.Scanner;

public class Triangle extends SHAPE {

	//triangle extends shape so shape is uperclass and tri is subclass of shape
	
		Scanner sc= new Scanner(System.in);
		int l,b,h;
		
		void length()
		{
			l = sc.nextInt();
		}
		
		void breadth()
		{
			b = sc.nextInt();
		}
		
		void height()
		{
			h = sc.nextInt();
		}
		
		void CountCorners()
		{
			System.out.println("Corners of shape=3");
		}
		
		void area()
		{
			System.out.println("area of shape= " + 0.5*h*b);
		}
		
		

	

}
