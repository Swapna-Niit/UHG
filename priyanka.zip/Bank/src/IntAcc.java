import java.util.Scanner;

public class IntAcc extends ProtectedAcc
{
	BasicAcc b=new BasicAcc();
	float in;
	void interest()
	{
		in= 0.05f*b.bal;
	}
}
