import java.util.Scanner;

public class ProtectedAcc extends BasicAcc
{
	Scanner sc=new Scanner(System.in);
	int pin;
	void pin()
	{
		pin=sc.nextInt();
	}
	
}
