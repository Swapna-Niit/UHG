import java.util.Scanner;

public class MinAcc extends ProtectedAcc
{
	
	float min;
	
	void min()
	{
		min=1500;
		System.out.println("Min Balance = "+min);
	}
	
	float pen;
	BasicAcc b=new BasicAcc();
	void pen()
	{
		if(b.bal>min)
		{
			System.out.println("No penalty");
		}
		else
		{
			pen= (0.1f*min);
			System.out.println("penalty = " + pen);
		}
	}
	
	float in;
	void intr()
	{
		in=0.06f*bal;
	}
}
