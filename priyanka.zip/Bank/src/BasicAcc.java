import java.util.Scanner;

public class BasicAcc {
	Scanner sc=new Scanner(System.in);
	String n;
	
	void name()
	{
		n = sc.nextLine();
	}
	
	float bal;
	
	void balance()
	{
		bal=sc.nextInt();
	}
	
	float int_rate;
	
	void int_rate()
	{
		int_rate=sc.nextInt();
	}
	
	
}
