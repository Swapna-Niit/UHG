import java.util.Scanner;

public class BankMain 
{

	public static void main(String[] args) 
	{
		System.out.println("Enter name---");
		BasicAcc bb= new BasicAcc();
		bb.name();
		
		System.out.println("Enter balance---");
		bb.balance();
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter account type---");
		String acc = null;
		acc = sc.nextLine();
		
		switch(acc)
		{
		case "min":
		{
			MinAcc m= new MinAcc();
			m.min();
			m.pen();
			m.intr();
		}
		
		case "inacc":
		{
			IntAcc i =new IntAcc();
			i.interest();
		}
		case "cd":
		{
			CDAcc c=new CDAcc();
			c.penalty();
		}
		}
	}

}
