import java.util.Scanner;

public class CDAcc extends ProtectedAcc
{
	BasicAcc b=new BasicAcc();
	
	float pen1,intr;
	void penalty()
	{
		if(b.bal>10000f)
		{
			System.out.println("No penalty");
			intr = 0.07f*b.bal;
			System.out.println("Interest = " + intr);
		}
		else
		{
			pen1= 1500f;
			System.out.println("penalty = " + pen1);
		}
		
	}
	
}
