package Student_info;

public class Main_SS extends Result {

	Main_SS(int i, String n) 
	{
		super(i, n);
	}

	public static void main(String[] args) 
	{
		Result rr=new Result(101, "pihu");
		rr.Mrk(11,165,26);
		rr.zzz();
		

	}

}
