package Student_info;

public class Marks extends Student 
{

	Marks(int i, String n) 
	{
		super(i, n);
		
	}
	
	 int Mrk(int a,int b,int c)
	{
		a=English;
		b=Bio;
		c=Chemistry;
		System.out.println(a + "\t" + b + "\t" + c);
		return 0;
	}

	int English=15;
	int Bio=63;
	int Chemistry=11;
	
}
