package Student_info;

public class Student 
{
	Student(int i,String n)
	{
		i=id;
		n=name;
	}
	
	int id=101;
	String name="pihu";
}
