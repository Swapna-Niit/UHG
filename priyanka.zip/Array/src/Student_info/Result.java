package Student_info;

public class Result extends Marks
{

	Result(int i, String n) 
	{
		super(i, n);
	}
	void zzz()
	{
		int r=English + Bio + Chemistry;
		
		System.out.println("The result is= " + r);
	}
	

}
