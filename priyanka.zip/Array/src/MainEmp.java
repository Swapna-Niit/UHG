
public class MainEmp extends Employee{

	MainEmp(int i, String n, int s) 
	{
		super(i, n, s);
	}

	public static void main(String[] args) 
	{
		Employee arr[]=new Employee[18];
		arr[0]= new Employee(123,"pihu",20000.857);
		arr[1]=new Employee(234,"hd",37663.8847);
		

	}

}
