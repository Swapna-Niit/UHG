import java.util.Scanner;
public class Employee
{
	Employee(int i,String n,double d)
	{
		 id=i;
		 name=n;
		 sal=d;
	}
	int id;
	String name;
	double sal;
}

