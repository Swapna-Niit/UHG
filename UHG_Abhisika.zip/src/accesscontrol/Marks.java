package accesscontrol;

public class Marks extends Student {
	protected int m1,m2,m3,m4,m5;
	int calculateTotal(){
		return (m1+m2+m3+m4+m5);
	}

}
