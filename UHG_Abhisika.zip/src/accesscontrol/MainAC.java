package accesscontrol;

public class MainAC {
	public static void main(String...s){
		Result r1 = new Result();
		r1.id = 101; r1.name = "Dean";
		r1.m1 = 91; r1.m2 = 95; r1.m3 = 99; r1.m4 = 100; r1.m5 = 100;
		r1.finalScore = r1.calculateTotal();
		System.out.println("The total marks score by "+ r1.name+" is "+ r1.finalScore+" i.e. "+ (r1.finalScore/5)+"%.");
	}

}
