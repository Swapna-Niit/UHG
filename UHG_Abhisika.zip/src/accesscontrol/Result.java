package accesscontrol;

public class Result extends Marks {
	int finalScore;

}
