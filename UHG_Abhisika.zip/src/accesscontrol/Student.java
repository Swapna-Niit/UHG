package accesscontrol;

public class Student {
	int id;
	String name;

}
