package test;

public class MainShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Square s = new Square(4.5f);
		s.area();
		EconomicsTeacher e = new EconomicsTeacher(121,40000);
		e.teaches();
		ScienceTeacher s1 = new ScienceTeacher(111,50000);
		s1.teaches();

	}

}
