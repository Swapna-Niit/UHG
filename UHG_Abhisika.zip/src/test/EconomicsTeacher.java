package test;

public class EconomicsTeacher extends Teacher{
	EconomicsTeacher(int i, int s){
		id = i;
		sal = s;
		System.out.println("in economics teacher constructor");
	}
	void teaches(){
		System.out.println("Economics teacher teaches economics!Her salary is " + sal);
	}

}
