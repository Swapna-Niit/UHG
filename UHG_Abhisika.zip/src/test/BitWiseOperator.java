package test;

import java.util.Scanner;

public class BitWiseOperator {
	Scanner sc = new Scanner(System.in);
	int x1,x2;
	public void read(){
		System.out.println("enter first value:");
		x1 = sc.nextInt();
		System.out.println("enter second value:");
		x2 = sc.nextInt();
	}
	
	void bitAnd(){
		System.out.println("the result of bitwise and is " + (x1 & x2));
	}
	void bitOr(){
		System.out.println("the result of bitwise or is " + (x1 | x2));
	}
	void bitNot(){
		System.out.println("the result of bitwise not is " + (~x1));
	}
	void bitXor(){
		System.out.println("the result of bitwise Xor is " + (x1 ^ x2));
	}
	void bitShiftRight(){
		System.out.println("the result of bitwise right shift is " + (x1 >> 2));
	}
	void bitShiftLeft(){
		System.out.println("the result of bitwise left shift is " + (x1 << 2));
	}
	void bitShiftRightZ(){
		System.out.println("the result of bitwise right shift zero fill is " + (x1 >>> 2));
	}
	

}
