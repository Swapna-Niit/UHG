package test;

public class Department {
	int did;
	String dname;

}
