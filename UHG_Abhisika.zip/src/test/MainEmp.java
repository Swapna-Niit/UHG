package test;

public class MainEmp {
	public static void main(String...s){
		Employee emp[] = new Employee[3];
		for ( int i=0; i<emp.length; i++) {
			emp[i]=new Employee();
			}
		emp[0].id = 101;emp[0].name="Aryana";emp[0].sal = 10000f;
		emp[1].id = 102;emp[1].name="Arya";emp[1].sal = 11000f;
		emp[2].id = 103;emp[2].name="Vihaan";emp[2].sal = 15000f;
		Department d[] = new Department[4];
		for ( int i=0; i<d.length; i++) {
			d[i]=new Department();
			}
		d[0].did = 21;d[0].dname = "Finance";
		d[1].did = 22;d[1].dname = "Marketing";
		d[2].did = 23;d[2].dname = "Research&Development";
		d[3].did = 24;d[3].dname = "Maintainance";
		
		for(int i=0;i<3;i++){
			System.out.println("Employee "+emp[i].id+"'s name is "+emp[i].name+" and salary is "+emp[i].sal);
		}
		for(int i=0;i<4;i++){
			System.out.println("Department "+d[i].did+"'s name is "+d[i].dname);
		}
		
	}

}
