package test;

import java.util.Scanner;

public class StringDuplicate {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a string:");
		String s = sc.nextLine();
		int f=0,n=s.length();
		for(int i=1;i<n;i++){
				for(int j=0;j<i;j++){
					if(s.charAt(j)==s.charAt(i)) {f=1;System.out.println(s.charAt(j));}
				}
		
		}
		if(f==1) System.out.println("duplicates present!!");
	}

}
