package test;

import java.util.Scanner;
/**
 * 
 * @author Trainee Staff
 *
 */

public class Addition {
	Scanner sc = new Scanner(System.in);
	int x1,x2;
	/**
	 * reading the values to add
	 */
	public void read(){
		System.out.println("enter first value:");
		x1 = sc.nextInt();
		System.out.println("enter second value:");
		x2 = sc.nextInt();
	}
	/**
	 * adding the two values
	 */
	public void add(){
		System.out.println("the sum of two values is "+ (x1+x2));
	}

}
