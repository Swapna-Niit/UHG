package test;

import java.util.Scanner;

public class p2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a,b,c;
		System.out.println("enter the 3 angles:");
		a = sc.nextInt();
		b = sc.nextInt();
		c = sc.nextInt();
		if((a+b+c)!=180) System.out.println("error!!the angle sum is not 180!");
		else{
			if(a==90 || b==90 || c==90) System.out.println("yes!the triangle is a right-triangle!");
			else System.out.println("No! the triangle is not a right-triangle!");
		}
		
	}

}
