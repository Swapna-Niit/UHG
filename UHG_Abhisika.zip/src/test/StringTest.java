package test;

import java.util.Scanner;

public class StringTest {
	
	public static void main(String...s){
		String s1 = "My new pen is awesome! ";
		String s2 = new String();
		String s3 = new String("I'm loving it!");
		char[] str = {'w','t','f'};
		String s4 = new String(str);
		System.out.println(s1 + s3);
		System.out.println(s1.concat(s4));
		System.out.println(s1.length());
		System.out.println(s1.lastIndexOf('e'));
		//s3 = s1;
		System.out.println(s1.hashCode());
		System.out.println(s3.hashCode());
		//duplicate words in a string
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a string:");
		String s5 = sc.nextLine();
		int f=0;
		String a[] = s5.split(" ");
		for(int i=1;i<a.length;i++){
			for(int j=0;j<i;j++){
				if(a[i].equals(a[j])) {System.out.println(a[i]);f=1;}
			}
		}
		if(f==1) System.out.println("duplicate word found!");
		else System.out.println("No duplicate words found!");
		sc.close();
	}

}
