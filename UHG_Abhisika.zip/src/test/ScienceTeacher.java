package test;

public class ScienceTeacher extends Teacher{
	ScienceTeacher(int i, int s){
		id = i;
		sal = s;
		System.out.println("in science teacher constructor");
	}
	void teaches(){
		System.out.println("Science teacher teaches Science!Her salary is " + sal);
	}

}
