package test;

public class Employee {
	int id;
	float sal;
	String name;

}
