package test;

public class Teacher {
	int id,sal;
	Teacher(){
		System.out.println("in teacher constructor");
	}
	void teaches(){
		System.out.println("teachers teaches!");
	}

}
