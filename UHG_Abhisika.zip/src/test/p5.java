package test;

import java.util.Scanner;

public class p5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,i,s=0,p=1,q,r;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number:");
		n = sc.nextInt();
		if(n<10) System.out.println("The number is a spy number.");
		else{
		while(n>10){
			q = n/10; r = n%10;
			s+=r;
			p*=r;
			n=q;
		}
		s+=n;
		p*=n;
		if(s==p)System.out.println("The number is a spy number!");
		}

	}

}
