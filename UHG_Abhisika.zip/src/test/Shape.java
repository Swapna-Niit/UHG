package test;

public class Shape {
	Shape(){
		System.out.println("in shape class constructor");
	}
	void readLength(){
		System.out.println("length of shape");
	}
	void readBreadth(){
		System.out.println("breadth of shape");
	}
	
	void area(){
		System.out.println("area of shape");
	}
	void perimeter(){
		System.out.println("perimeter of shape");
	}
	void countCorners(){
		System.out.println();
	}

}
