package test;

public class ArithematicOperations {
	public static void main(String[] args) {
		
		System.out.println(2*3/4+4/4+8-2+5/8);
		System.out.println(3/2*4+3/8+3);
		double a=1,b=1,c=1,l=1,m=1,q=1,r=1,z,d=1,g=1,v=1,x=1,y=1;
		z = (8.8*(a+b)*2/c-0.5+2*a/(q+r))/(a+b)*(l/m);
		x = (-b+(b*b)+2*4*a*c)/(2*a);
		r = (2*v+6.22*(c+d))/(g+v);
		a = (7.7*b*(x*y+a)/c-0.8+2*b)/(x+a)*(l/y);
		System.out.println(z);
		System.out.println(x);
		System.out.println(r);
		System.out.println(a);
	}

}
