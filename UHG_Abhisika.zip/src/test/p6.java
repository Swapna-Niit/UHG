package test;

import java.util.Scanner;

public class p6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,i,s=0,p=1,q,r;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number:");
		n = sc.nextInt();
		if((n*n)%10==(n%10)) System.out.println("the number is automorphic!");
		else System.out.println("sorry! the number is not automorphic!");

	}

}
