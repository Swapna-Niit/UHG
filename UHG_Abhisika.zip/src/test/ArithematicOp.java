package test;


public class ArithematicOp {
	public static void main(String[] args){
		Addition ad = new Addition();
		ad.read();
		//ad.x1 = 120;
		//ad.x2=130;
		ad.add();
		BitWiseOperator bw = new BitWiseOperator();
		bw.read();
		bw.bitAnd();
		bw.bitOr();
		bw.bitNot();
		bw.bitXor();
		bw.bitShiftRight();
		bw.bitShiftLeft();
		bw.bitShiftRightZ();
	}

}
