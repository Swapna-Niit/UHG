package test;

import java.util.Scanner;

public class DataTypes {
	//boolean b1=true;

	public static void main(String[] args) {
		
		System.out.println('A'+0);
		int i=33; 
		float a=23.124f;
		long l=1234567890;
		System.out.println("value of i is "+i);
		System.out.println("value of a is "+a);
		System.out.println("value of l is "+l);
		//typecasting
		short s = 20;
		i=s;//implicit conversion
		double d = a;
		i = (int)a; //explicit conversion
		//array declaration
		int x[] = new int[5];
		System.out.println(x.length);
		Scanner sc = new Scanner(System.in);
		int sum=0,s1=0,n;
		for(int ii=0;ii<5;ii++){
			System.out.println("enter the "+ii+"th element:");
			x[ii] = sc.nextInt();
			sum+=x[ii];
		}
		System.out.println("the sum is "+sum);
		//-----------------------------------------------
		System.out.println("enter the size of char array, n:");
		n = sc.nextInt();
		char ch[]= new char[n];
		System.out.println("enter the elements of the array:");
		for(int j=0;j<n;j++)
			ch[j]=sc.next().charAt(0);
		for(int j=n-1;j>=0;j--){
			System.out.print(ch[j]);
			s1+=ch[j];
		}
			System.out.println("\nthe sum of characters is "+ s1);
		sc.close();

	}

}
