package test;

public class p4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,n=9;
		for(i=1;i<=n;i+=2){
			for(int j=0;j<(n-i)/2;j++) System.out.print(' ');
			for(int j=0;j<i;j++) System.out.print(i);
			System.out.println();
		}

	}

}
