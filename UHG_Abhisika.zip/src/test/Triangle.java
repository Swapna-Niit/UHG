package test;

import java.util.Scanner;

public class Triangle extends Shape{
	Triangle(){
		System.out.println("in triangle class constructor");
	}
	Scanner sc = new Scanner(System.in);
	float l,b,h;
	void readLength(){
		l = sc.nextInt();
	}
	void readBreadth(){
		b = sc.nextInt();
	}
	void readHeight(){
		h = sc.nextInt();
	}
	void countCorners(){
		System.out.println("3 corners");
	}
	void area(){
		System.out.println("area of triangle = "+ (0.5*b*h));
	}
	void perimeter(){
		System.out.println("perimeter of shape");
	}

}
