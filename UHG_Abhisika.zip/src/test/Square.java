package test;


public class Square extends Triangle {
	Square(){
		System.out.println("in square class constructor");
	}
	Square(float side){
		l = side;
	}
	void countCorners(){
		System.out.println("4 corners");
	}
	void area(){
		System.out.println("the area of the square is " + (l*l));
	}
}
