package test;

public class p1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=10;
		for(int i=0;i<n;i++){
			if(i<(n/2)){
		for(int j=i;j<(n/2);j++)
			System.out.print("*");
		}
			else{
			for(int j=0;j<=(i-(n/2));j++)
				System.out.print("*");
			}
			System.out.println();
		}
			

	}

}
