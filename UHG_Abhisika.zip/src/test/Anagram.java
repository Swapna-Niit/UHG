package test;

import java.util.Scanner;

public class Anagram {
	public static void main(String...s){
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size of first array:");
		int c=0,n2, n1 = sc.nextInt();
		System.out.println("enter size of second array:");
		n2 = sc.nextInt();
		if(n1!=n2) System.out.println("the  strings can't be anagram!");
		else{
		char[] a1 = new char[n1];
		char[] a2 = new char[n2];
		char x;
		System.out.println("enter elements of first array:");
		for(int i=0;i<n1;i++) a1[i]=sc.next().charAt(0);
		System.out.println("enter elements of second array:");
		for(int i=0;i<n2;i++) a2[i]=sc.next().charAt(0);
		for(int i=0;i<n1;i++){
			for(int j=i+1;j<n1;j++){
				if(a1[i]>a1[j]) {
					
					x = a1[i];
					a1[i]=a1[j];
					a1[j]=x;
				}
			}
		}
		for(int i=0;i<n2;i++){
			for(int j=0;j<n1;j++) {
				if(a2[i]==a1[j]) c++;
			}
		}
		if(c==n2) System.out.println("they are anagram!");
		else System.out.println("they are not anagram!");
		}
		
	}

}
