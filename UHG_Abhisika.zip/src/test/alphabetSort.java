package test;

import java.util.Scanner;

public class alphabetSort {
	
	public static void main(String...s){
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size of array:");
		int n = sc.nextInt();
		char[] arr = new char[n];
		char x;
		for(int i=0;i<n;i++) arr[i]=sc.next().charAt(0);
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++){
				if(arr[i]>arr[j]) {
					
					x = arr[i];
					arr[i]=arr[j];
					arr[j]=x;
				}
			}
		}
		for(int i=0;i<n;i++) System.out.print(arr[i]);
		
		
	}

}
