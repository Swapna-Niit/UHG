package test;

import java.util.StringTokenizer;
import java.util.StringJoiner;

public class StrinBf {
	
	static void revToken(String s){
		int n = s.length();
		for(int i=n-1;i>=0;i--)
		 System.out.print(s.charAt(i));
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "This is a string";
		StringBuffer sb = new StringBuffer(s1);
		System.out.println(sb.insert(9, " java "));
		sb.append(" which is immutable.");
		System.out.println(sb);
		String str = sb.toString();
		System.out.println(str);
		StringTokenizer st = new StringTokenizer(s1," ");
		while(st.hasMoreTokens()){
			System.out.println();
			String s = st.nextToken();
			revToken(s);
			
		}
		

	}

}
