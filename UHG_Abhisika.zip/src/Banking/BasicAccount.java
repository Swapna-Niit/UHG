package Banking;

import java.util.Scanner;

public class BasicAccount {
	Scanner sc = new Scanner(System.in);
	String name;
	float balance;
	void readDetails(){
		System.out.println("Enter your name and the amount you want to keep in your account:");
		name = sc.next();
		balance = sc.nextFloat();
	}
	void checkBalance(){
		System.out.println("your balance is "+balance);
	}
	

}
