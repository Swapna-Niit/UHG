package Banking;

public class SalaryAccount extends BasicAccount {
	float rate=0.05f;
	void giveInterest(){
		balance = balance + rate*balance;
		System.out.println("balance after interest is "+ balance);
	}

}
