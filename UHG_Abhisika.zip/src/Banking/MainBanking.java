package Banking;

import java.util.Scanner;

public class MainBanking {
	public static void main(String[] args){
		int f;
		System.out.println("Enter 1:SB Account\n2:Salary Account\n3:Current Account");
		Scanner sc = new Scanner(System.in);
		f = sc.nextInt();
		switch(f){
		case 1: SBAccount a1 = new SBAccount();
		a1.readDetails();
		a1.penaltyCheck();
		a1.giveInterest();
		break;
		case 2: SalaryAccount a2 = new SalaryAccount();
		a2.readDetails();
		a2.giveInterest();
		break;
		case 3: CurrentAccount a3 = new CurrentAccount();
		a3.readDetails();
		a3.penaltyCheck();
		a3.giveInterest();
		break;
		
		
		}
			
	}

}
