package Banking;

public class SBAccount extends BasicAccount {
	float minimum=1500, penalty=0.1f,rate=0.06f;
	void penaltyCheck(){
		if(balance < minimum){
			balance = balance - penalty*balance;
			System.out.println("Balance is less than the minimum balance. Penalty charged!Present Balance is "+balance);
		 
		}
		else System.out.println("Balance is above minimum, i.e. "+balance);
	}
	void giveInterest(){
		balance = balance + rate*balance;
		System.out.println("balance after interest is "+ balance);
	}

}
