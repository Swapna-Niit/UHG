package statickw;

public class MainStatic {
	public static void main(String...s){
		Vehicle v = new Car();
		//Car c = new Car();
		System.out.println(v instanceof Vehicle);
		System.out.println(v instanceof Car);
		v.kmToMiles(500);
	}

}
