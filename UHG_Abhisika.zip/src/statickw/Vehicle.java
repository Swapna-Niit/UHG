package statickw;

public class Vehicle {

	public static void kmToMiles(int km){
		System.out.println("'inside parent class' static method");
	}

}
