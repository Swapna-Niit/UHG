package statickw;

public class Car extends Vehicle {
	public static void kmToMiles(int km){
		System.out.println("'inside child class' static method");
	}

}
