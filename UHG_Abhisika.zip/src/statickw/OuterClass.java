package statickw;

public class OuterClass {
	public void example(){
		System.out.println("this is outer class");
	}
	
	public class InnerClass{
		public void example(){
			System.out.println("this is inner class");
		}
	}
	public static void main(String...s){
		OuterClass oic = new OuterClass();
		OuterClass.InnerClass o = oic.new InnerClass();
		o.example();
	}

}
