package inheritance;

public class C extends B {
	
	void printInfo(){
		System.out.println("c class method");
	}


}
