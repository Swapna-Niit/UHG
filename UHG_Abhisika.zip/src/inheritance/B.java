package inheritance;

public class B extends A {
	int var = 150;
	//overriding method
	void printInfo(){
		System.out.println("B class method");
		System.out.println(var+super.var);
	}

	void printInfo(String s, int age){
		this.printInfo();
		System.out.println(s + " is "+ age + " years old.");
	}

}
