package inheritance;

public class Inheritance {
	
	public static void main(String...s){
		
		C c = new C();
		c.printInfo("yoyo");
		//c.printInfo("yoyo",5);
		B b = new B();
		b.printInfo("yoyo",5);
	}

}
