package interfacedemo;

public interface DataBase {
	int a=30;
	void connectDB();
	default void connectionValues(){
		System.out.println("read the DB url, uname and pwd");
	}
	static void values(){
		System.out.println("in static method");
	}

}
