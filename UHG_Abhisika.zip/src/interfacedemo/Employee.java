package interfacedemo;

public class Employee {
	
	static int empid = 123;
	int sal=200000;
	void readEmpId(){
		System.out.println(empid);
	}
	static void readSal(){
		//System.out.println(sal);
	}
	public static void main(String...s){
		Employee e = new Employee();
		Employee.empid = 1225;
		e.sal = 300000;
		
	}

}
