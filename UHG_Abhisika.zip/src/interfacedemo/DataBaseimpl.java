package interfacedemo;

public class DataBaseimpl implements DataBase {


	@Override
	public void connectDB() {
		// TODO Auto-generated method stub
		System.out.println("connecting to DB");
		DataBase.values();
	}

}
