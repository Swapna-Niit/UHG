package interfacedemo;

public class InterfaceMainClass {
	public static void main(String[] args){
		DataBaseimpl dbi = new DataBaseimpl();
		dbi.connectionValues();
		dbi.connectDB();
	}

}
