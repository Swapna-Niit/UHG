package interfacedemo;

public class StaticBlockDemo {
	
	static{
		System.out.println("inside the static block!");
	}
	public static void main(String...s){
		StaticBlockDemo sbd = new StaticBlockDemo();
	}
	

}
