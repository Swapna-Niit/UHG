import java.util.Scanner;

public class Printstars {
	
	
	
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		int i, j;
		System.out.println("Enter the size");
		int asize= sc.nextInt();
		for(i=asize;i>0;i--)
		{
			j=i;
			while(j!=0)
			{
				System.out.print("* ");
				j--;
			}
			
				System.out.println();
			
		}
		for(i=0;i<asize;i++)
		{
			j=i+1;
			while(j!=0)
			{
				System.out.print("* ");
				j--;
			}
			
			
				System.out.println();
			
		}
		sc.close();
	}	

}
