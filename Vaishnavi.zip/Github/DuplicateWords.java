package sample;

import java.util.Scanner;

public class DuplicateWords {
public static void main(String[] args)
{
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the string");
	String st=new String(sc.nextLine());
	String[] arr=st.split(" ");
	String temp;
	int len= arr.length;
	int i,j;
	for(i=0;i<len;i++)
	{
		for(j=0;j<len-i-1;j++)
		{
			if((arr[j].compareTo(arr[j+1]))>0)
			{
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
	temp="";
	for(i=0;i<len;i++)
	{
		
		if(!temp.equals(arr[i]))
		{
			int count=1;
			temp=arr[i];
			for(j=i+1;j<len;j++)
			{
				if(temp.equals(arr[j]))
				{
					count++;
				}
		}
		if(count>1)
		{
			System.out.println("The duplicate is "+temp+" repeated "+count+" times");
		}
		}
	}
}

}
