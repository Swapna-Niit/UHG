package sample;

public class Result extends Marks{

	Result(int id, String name, float totalmarks) {
		super(id, name, totalmarks);
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args)
	{
		Marks st[]= new Marks[3];
		st[0]= new Marks(1,"Vaish",90);
		st[1]= new Marks(2,"kou",56);
		st[2]= new Marks(3,"ahluwaliya",20);
		st[0].print(st[0]);
		st[1].print(st[1]);
		st[2].print(st[2]);
		}

}
