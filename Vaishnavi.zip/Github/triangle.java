import java.util.Scanner;

public class triangle {
Scanner sc= new Scanner(System.in);
int an1, an2, an3;
public void read()
{
	System.out.println("Enter the angles");
	an1= sc.nextInt();
	an2= sc.nextInt();
	an3= sc.nextInt();
}
public void check()
{
	if(an1==90 || an2==90 || an3==90)
	{
		System.out.println("The triangle is right angled");
	}
	else
	{
		System.out.println("The triangle is not right angled");
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		triangle tri= new triangle();
		tri.read();
		tri.check();

	}

}
