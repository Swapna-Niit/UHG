package sample;

public class Student {
	int id;
	String name;
	
	Student(int id, String name)
	{
		this.id=id;
		this.name=name;
	}
	void print(Marks m)
	{
		if(m.totalmarks>35)
		{
			System.out.println("id: "+m.id+" "+m.name+" is pass");
		}
		else
		{
			System.out.println("id: "+m.id+" "+m.name+" is fail");
		}
	}
	

}
