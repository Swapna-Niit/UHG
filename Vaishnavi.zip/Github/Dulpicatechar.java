package sample;

import java.util.Scanner;

public class Dulpicatechar {
public static void main(String[] args)
{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the string");
	String str= new String( sc.nextLine());
	int n= str.length();
	char cha[]= str.toCharArray();
	char temp='\0';
	int i,j;
	for(i = 0; i < n; i++)
    {
        for(j = 0; j < n-i-1; j++)
        {
            if( cha[j] > cha[j+1])
            {
                // swap the elements
                temp = cha[j];
                cha[j] = cha[j+1];
                cha[j+1] = temp;
            } 
        }
    }
	for(i=0;i<n;i++)
	{
		System.out.println(cha[i]);
	}
	/*for(i=0;i<n;i++)
	{
		
		if(temp!=cha[i])
		{
			int count=1;
		temp=cha[i];
		for(j=i+1;j<n;j++)
		{
			if(temp==cha[j])
			{
				count++;
			}
		}
		if(count>1)
		{
			System.out.println("The duplicate is "+temp+" repeated "+count+" times");
		}
		}
	}*/

}
}