package sample;

import java.util.Scanner;

public class Anagrams {
	public char[] reverse(String str)
	{
		int i,j;
		int n=str.length();
		char[] cha=str.toCharArray();
		char temp;
		for(i = 0; i < n; i++)
	    {
	        for(j = 0; j < n-i-1; j++)
	        {
	            if( cha[j] > cha[j+1])
	            {
	                // swap the elements
	                temp = cha[j];
	                cha[j] = cha[j+1];
	                cha[j+1] = temp;
	            } 
	        }
	    }
		return cha;
	}
	public void compare(char[] char1, char[] char2)
	{
		int flag=0;
		for(int i=0;i<char1.length;i++)
		{
			if(char1[i]==char2[i])
			{
				flag++;
			}
		}
		if(flag==char1.length)
		{
			System.out.println("the given strings are anagrams");
		}
		else
		{
			System.out.println("ths given strings are not anagrams");
		}
		
	}
	public static void main(String[] args)
	{
		Anagrams ana= new Anagrams();
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the strings");
		String str1= new String(sc.nextLine().toUpperCase());
		String str2= new String(sc.nextLine().toUpperCase());
		char cha1[]= ana.reverse(str1);
		char cha2[]= ana.reverse(str2);
		ana.compare(cha1, cha2);
		
	}
}
