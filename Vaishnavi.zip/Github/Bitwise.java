import java.util.Scanner;

public class Bitwise {

Scanner sc= new Scanner(System.in);
int fval,sval,tval;
public void read()
{
	System.out.println("Enter first value");
	fval= sc.nextInt();
	System.out.println("Enter second value");
	sval= sc.nextInt();
	
}
public void bitOr()
{
System.out.println("The bitwise OR is "+(fval|sval));	
}public void bitExor()
{
System.out.println("The bitwise EXOR is "+(fval^sval));	
}
public void bitNot()
{
System.out.println("The bitwise NOT is "+(~sval));	
}
public void bitAnd()
{	
	System.out.println("The bitwise AND is "+(fval&sval));
}
public void bitAndassign()
{	
	System.out.println("The bitwise AND Assignment is "+(fval&=sval));
}
public void Shiftright()
{	
	System.out.println("The bitwise Shiftright is "+(fval>>2));
}
public static void main(String[] args)
{
	Bitwise bt= new Bitwise();
	bt.read();
	bt.bitOr();
	bt.bitExor();
	bt.bitNot();
	bt.bitAndassign();
	bt.bitAnd();
	bt.Shiftright();
}
}
