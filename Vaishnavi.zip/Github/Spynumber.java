import java.util.Scanner;

public class Spynumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number");
		int num= sc.nextInt();
		int sum=0,prod=1,mod;
		while(num!=0)
		{
			mod=num%10;
			sum=sum+mod;
			prod=prod*mod;
			num=num/10;
		}
		if(sum==prod)
		{
			System.out.println("The number is spy number");
		}
		else
		{
			System.out.println("The number is not a spy number");
		}
		
		
	}

}
