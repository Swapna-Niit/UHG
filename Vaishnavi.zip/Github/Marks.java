package sample;

public class Marks extends Student{
	float totalmarks;

	Marks(int id, String name, float totalmarks) {
		super(id, name);
		this.totalmarks= totalmarks;
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
