package sample;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Reversestring {
public void reverse(StringTokenizer str)
{
	while(str.hasMoreTokens())
	{
		char ch[]= str.nextToken().toCharArray();
		for(int i=(ch.length)-1;i>=0;i--)
		{
			System.out.print(ch[i]);
		}
		System.out.print(" ");
	}
	
}

public static void main(String[] args)
{
	Reversestring strrev= new Reversestring();
	Scanner sc= new Scanner(System.in);
	String str= new String(sc.nextLine());
	StringTokenizer st= new StringTokenizer(str," ");
	strrev.reverse(st);
	sc.close();
}
}
