import java.util.Scanner;

public class Automorphic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number");
		int num= sc.nextInt();
		int i=0,num1,temp=0;
		num1= num*num;
		
		while(num1!=0)
		{
			int exp=(int)Math.pow(10,i);
			temp=temp+(exp*(num1%10));
			if(temp==num)
			{
				System.out.println("The number is automorphic "+ temp);
				break;
			}
			num1=num1/10;
			i++;
		}
		sc.close();
		
	}

}
