
public class Trinumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int temp,num=5, i,j,k;
		for(i=1;i<=num;i++)
		{
			temp=(2*i)-1;
			k=temp;
			for(j=1;j<=num-i;j++)
			{
				System.out.print(" ");
			}
			while(k!=0)
			{
				System.out.print(temp);
				k--;
			}
			System.out.println("");
		}

	}

}
