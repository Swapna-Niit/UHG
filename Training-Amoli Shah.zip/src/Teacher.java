
public class Teacher {
	Teacher()
	{
		System.out.println("Teacher called");
	}
	Teacher(int i,int s)
	{
		t_id =i;
		salary = s;
		System.out.println("Teacher called with parameters");
	}
	int t_id;
	int salary;
	void teaches()
	{
		System.out.println("Teacher teaches");
	}

}
