
public class ScienceTeacher extends Teacher {
	ScienceTeacher()
	{
		System.out.println("ScienceTeacher Called");
	}
}
