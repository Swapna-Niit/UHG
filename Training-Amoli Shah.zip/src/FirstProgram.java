
public class FirstProgram {
	public static void main(String[] args)
	{
	System.out.print("This is my first program");
	}
}
