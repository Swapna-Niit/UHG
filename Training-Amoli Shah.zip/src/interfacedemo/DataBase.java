package interfacedemo;

public interface DataBase {
	int a = 50;
    void connectDB();
    default void ConnectionValues()
    {
    	System.out.println("Reads DR URL");
    }
    static void values()
    {
    	System.out.println("Reads DR URL");
    }
}
