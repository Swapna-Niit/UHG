package interfacedemo;

public class InterfaceMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataBaseImp dbi = new DataBaseImp();
		dbi.ConnectionValues();
		dbi.connectDB();
		
		
	}

}
