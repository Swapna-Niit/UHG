package interfacedemo;

public class DataBaseImp implements DataBase {

@Override
public void connectDB() {
	// TODO Auto-generated method stub
	System.out.println("Connection to db");
}
}
