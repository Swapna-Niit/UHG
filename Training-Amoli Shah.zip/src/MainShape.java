
public class MainShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Triangle t = new Triangle();
//		t.readLength();
//		t.readBreadth();
//		t.readHeight();
//		t.area();
		
		Square s = new Square();
	}

}
