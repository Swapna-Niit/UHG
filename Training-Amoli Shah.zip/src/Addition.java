import java.util.Scanner;

public class Addition {
	Scanner sc = new Scanner(System.in);
	int f_val,s_val;
	/**
	 *  Method that reads the data from user
	 */
	public void read()
	{
		System.out.println("Enter First Value: ");
	    f_val = sc.nextInt();
		System.out.println("Enter Second Value: ");
		s_val = sc.nextInt();
		
	}
	/**
	 *  Method to add the data
	 */
	public void add()
	{
		System.out.println("Addition of two values is: "+(f_val+s_val));
	}
}
