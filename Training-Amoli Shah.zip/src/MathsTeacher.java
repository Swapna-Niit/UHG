
public class MathsTeacher extends Teacher {

	MathsTeacher()
	{
		System.out.println("MathsTeacher Called "+t_id+" "+salary);
	}
}
