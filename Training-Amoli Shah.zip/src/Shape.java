
public class Shape {
	Shape()
	{
		System.out.println("shape class");
	}
	 void area()
	 {
		 System.out.println("Area of shape");
	 }
	 void perimeter()
	 {
		 System.out.println("perimeter of shape");
	 }
	 void readLength()
	 {
		 System.out.println("length of shape");
	 }
	 void readBreadth()
	 {
		 System.out.println("breadth of shape");
	 }
	 void countCorners()
	 {
		 System.out.println("unpredictable");
	 }
}
