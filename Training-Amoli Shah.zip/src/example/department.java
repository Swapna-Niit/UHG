package example;

public class department {
	int did;
	String dname;
}
