package example;

public class Employee {
	public Employee(int i, String string, float f) {
		// TODO Auto-generated constructor stub
		id = i;
		name = string;
		salary = f;
	}
	int id;
	String name;
	float salary;

}

