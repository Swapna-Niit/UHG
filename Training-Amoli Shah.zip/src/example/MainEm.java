package example;

public class MainEm extends Employee{

	public MainEm(int i, String string, float f) {
		super(i, string, f);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e[] =  new Employee[10];
		e[0] = new Employee(00,"Rama",5000.0f);
		e[1] = new Employee(01,"Srirama",10000.0f);
		e[2] = new Employee(02,"Balrama",15000.0f);
	}

}
