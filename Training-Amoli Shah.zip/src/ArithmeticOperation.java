import java.util.Scanner;

public class ArithmeticOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Addition ad = new Addition();
//		ad.read();
//		ad.add();
		
		//Bitwise Operator
//		BitwiseOperator b = new BitwiseOperator();
//		b.read();
//		b.bitNot();
//		b.bitAnd();
//		b.bitOr();
//		b.bitXor();
//		b.shiftRight();
//		b.shiftRightZero();
//		b.shiftLeft();
//		b.bitAndAssignment();
//		b.bitOrAssignment();
//		b.bitXorAssignment();
//		b.shiftRightZeroAssignment();
//		b.shiftLeftAssignment();

		//Pattern
//		for (int i=5;i>=1;i--)
//		{
//			for(int j=i;j>=1;j--)
//				System.out.print("* ");
//			System.out.println();
//		}
//		for (int i=1;i<=5;i++)
//		{
//			for(int j=1;j<=i;j++)
//				System.out.print("* ");
//			System.out.println();
//		}
		
		//Right Angle Triangle
//		Scanner sc  = new Scanner (System.in);
//		System.out.println("Enter the angles: ");
//		int angle1 = sc.nextInt();
//		int angle2 = sc.nextInt();
//		int angle3 = sc.nextInt();
//		if (angle1 + angle2 + angle3 ==180 && angle1 !=0 && angle2 !=0 && angle3 !=0 )
//		{
//			if (angle1 == 90 || angle2 ==90 || angle3==90)
//				System.out.println("Given angles form a right angled triangle");
//			else
//				System.out.println("Doesn't form a right angled triangle");
//		}
//		else
//			System.out.println("Angles don't form the triangles");
		
		//Duplicate in a char array
//		Scanner sc = new Scanner(System.in);
//		int size = sc.nextInt();
//		char ar[] = new char[size];
//		char dup[] = new char[size];
//		int m=0;
//		for(int i=0;i<size;i++)
//			ar[i] = sc.next().charAt(0);
//		for(int i=0;i<size;i++)
//		{
//			for(int j=i+1;j<size;j++)
//			{
//				if(ar[i]==ar[j])
//				{
//				ar[j]=' ';
//				dup[m] = ar[i];
//				m++;
//				break;
//				}
//			}
//		}
//		System.out.println("Duplicates are: ");	
//		for(int i=0;i<size;i++)
//		System.out.println(dup[i]);	
//		

		
		//Pattern
//		for(int i=1;i<=5;i++)
//		{
//			for(int j=5-i;j>0;j--)
//				System.out.print(" ");
//			for(int k=1;k<=(2*i-1);k++)
//				System.out.print((2*i-1));
//			System.out.println();
//		}
		
		//Spy number (1*1*2*4 = 1+1+2+4) => 1124 is spy number
//		Scanner sc = new Scanner(System.in);
//		int num = sc.nextInt();
//		int a;
//		int sum = 0,mul = 1;
//		while(num%10!=0)
//		{
//			a = num%10;
//			num = num/10;
//			sum = sum + a;
//			mul = mul * a;
//		}
//		if (sum == mul)
//			System.out.println("Given number is a spy number");
//		else
//			System.out.println("Not a spy number");
		
		
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int square=1;
		square = num*num;
		int dig=0,digit;
		int a,t,number,ori;
		ori = num;
		while(num%10!=0)
			{
				dig = dig+1;
				num = num/10;
			}
		digit = dig;
		number = 0;
		int p=1;
		while (square !=0 && dig>0)
		{
			a = square%10;
			square = square/10;
			t = digit - dig;
			System.out.print(t+"  ");
			for(int s=t;s>0;s--)
				p = p*10;
			System.out.print(p+"  ");
			number = p*a + number;
//			System.out.print(number + "  ");
			dig--;
		}
		
		if (number == ori)
			System.out.println("Automorphic number");
		else
			System.out.println("Not automorphic");
	}

}
