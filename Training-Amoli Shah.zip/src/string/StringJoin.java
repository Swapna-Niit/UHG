package string;

public class StringJoin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "Python Programming";
		String str2 = "Programming";
		System.out.println(String.join("-", str1,str2,"Language"));
		System.out.println(str1.regionMatches(7, str2, 0, str2.length()));

	}

}
