package string;

import java.util.Scanner;

public class example3 {
	//to sort the string in lexicographic order
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s;
		Scanner sc = new Scanner(System.in);
		s = sc.next();
		String l = lexicographicOrder(s);
		System.out.println(l);
	}
	
	public static String lexicographicOrder(String a)
	{
		int len = a.length();
		char temp;
		StringBuilder sb = new StringBuilder(a);
		for(int i=0;i<len;i++)
		{
			for(int j=i+1;j<len;j++)
			{
				if(sb.charAt(i)>sb.charAt(j))
				{
					temp = sb.charAt(i);
					sb.setCharAt(i, sb.charAt(j));
					sb.setCharAt(j, temp);
				}
			}
			
		}
		a = sb.toString();
		return a;
	}

}
