package string;

import java.util.Scanner;

public class Example {
	
	public static void main(String[] args) {
		//to print duplicate characters in a string without using function
//		String s;
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the String: ");
//		s = sc.nextLine();
//		
//		int len = s.length();
//		char dup[] = s.toCharArray();
//		int m=0;
//		for(int i=0;i<len;i++)
//		{
//			for(int j=i+1;j<len;j++)
//			{
//				if(dup[i] == dup[j])
//				{
//					System.out.println(dup[i]);
//					break;
//				}
//					
//			}
//		}
		
		
		//to print duplicate words in a string
		String s;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String: ");
		s = sc.nextLine();
		String a[] = s.split(" ");
//		for(int i=0;i<a.length;i++)
//		System.out.println(a[i]);
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i].equals(a[j]))
				{
					System.out.println(a[i]);
					break;
				}
			}
		}
	}

}
