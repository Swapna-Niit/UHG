package string;

import java.util.Scanner;

public class example4 {

	public static void main(String[] args) {
		// Anagrams check
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1st String");
		String in1 = sc.next();
		System.out.println("Enter 2nd String");
		String in2 = sc.next();
		in1 = in1.toLowerCase();
		in2 = in2.toLowerCase();
		boolean result = checkAnagrams(in1, in2);
		if (result)
			System.out.println(in1 + " and " + in2 + " are Anagrams");
		else
			System.out.println(in1 + " and " + in2 + " are not Anagrams");
		}
	public static boolean checkAnagrams(String s1,String s2)
	{
		String lex_s1,lex_s2;
		lex_s1 = example3.lexicographicOrder(s1);
		lex_s2 = example3.lexicographicOrder(s2);
		if(lex_s1.equals(lex_s2))
			return true;
		else
			return false;
	}
}
