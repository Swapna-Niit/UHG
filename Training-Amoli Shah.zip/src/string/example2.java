package string;

import java.util.Scanner;
import java.util.StringJoiner;
import java.util.StringTokenizer;

public class example2 {
	public static String arr[];
	static String s;

	//to convert string into tokens and reverse each word
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		s = sc.nextLine();
		toTokens(s);
		toReverse(arr);
		System.out.println("Reverse: ");
		System.out.println(s);
		
	}
	
	public static void toTokens(String str)
	{
//		StringTokenizer st = new StringTokenizer(str, "");
//		int i=0;
//		while(st.hasMoreTokens())
//		{
//			arr[i] = st.nextToken().toString();
//			i++;
//		}
		arr = str.split(" ");
		
	}
	public static void toReverse(String[] a)
	{
		//Using Predefined method
//		StringJoiner sj = new StringJoiner(" ");
//		for(int j=0;j<arr.length;j++)
//		{
//			StringBuilder sb = new StringBuilder(a[j]);
//			sb.reverse();
//			//a[j] = sb.toString();
//			sj.add(sb);
//		}
//		s = sj.toString();
		
		//Not using reverse()
		char q = ' ';
		StringJoiner sj = new StringJoiner(" ");
		for(int p=0;p<a.length;p++)
		{
			char temp[] = a[p].toCharArray();
			for(int m=0;m<temp.length/2;m++)
			{				
				q = temp[m];
				temp[m] = temp[temp.length-1-m];
				temp[temp.length-1-m] = q;
			}
			a[p] = new String(temp);	
			sj.add(a[p]);
		}
		s = sj.toString();
	}

}
