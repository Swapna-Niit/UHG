package string;
//import java.util.StringTokenizer;
import java.util.StringJoiner;
public class BasicString {
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "This is a String";
		String s2 = new String();
		String s3 = new String("This is 3rd way of creating the string which calls the constructorwith the parameter..String original");
		char[] str = {'t','h','i','s'};
		String s4 = s1;
		String s5 = "This is a String";
//		String s4 = new String(str);
//		System.out.println("Concatenation "+ s1+s4);
//		System.out.println("Concatenation" + s1.concat(s4));
//		System.out.println("Length is "+s1.length());
//		System.out.println("Substring "+s1.substring(2));
//		System.out.println("Substring "+s1.substring(2,6));
//		System.out.println("Character at "+s1.charAt(5));
//		System.out.println(s1.hashCode());
//		System.out.println(s4.hashCode());
//		System.out.println(s1.equals(s5));
//		System.out.println(s1.codePointCount(0, 8));
		
		//split method
//		String arr[] = s1.split(" ");
//		System.out.println(arr.length);
//		for(int i=0;i<arr.length;i++)
//			System.out.println(arr[i]);
		
		
		//String Buffer
//		StringBuffer sb = new StringBuffer(s1);
//		sb.append(" Mutable");
//		s1 = sb.toString();
//		System.out.println(s1);
		
		//String Tokenizer
//		StringTokenizer st = new StringTokenizer(s1," ");
//		while(st.hasMoreTokens())
//		System.out.println(st.nextToken());
		
		//String Joiner
		StringJoiner sj = new StringJoiner("=");
		sj.add("hey");
		sj.add("there");
		System.out.println(sj);
		
	}
	
}
