
public class Square extends Triangle{
	
	Square()
	{
		System.out.println("Square class");
	}
	void countCorners()
	 {
		 System.out.println("4 corners");
	 }
}
