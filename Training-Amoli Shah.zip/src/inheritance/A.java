package inheritance;

public class A {
	int var = 50;
	void printInfo()
	{
		System.out.println("A class method");
	}
	void printInfo(String s)
	{
		System.out.println("A class method" + s);
	}
}
