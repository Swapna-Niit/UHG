package inheritance;

public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = new A();
		C c = new C();
		c.printInfo("hey");
		
	}

}
