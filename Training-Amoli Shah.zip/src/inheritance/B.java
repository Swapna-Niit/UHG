package inheritance;

public class B extends A{
	int var = 150;
	void printInfo()
	{
		super.printInfo();
		System.out.println("B class method");
		System.out.println("Sum: "+(var+super.var));
	}
	void printInfo(String s, int age)
	{
		System.out.println("B class method " + s + "  " + age);
	}
}
