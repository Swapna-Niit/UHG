import java.util.Scanner;

public class Triangle extends Shape{
	
	Triangle()
	{
		System.out.println("triangle class");
	}
	Scanner sc = new Scanner(System.in);
	int l,b,h;
	void readHeight()
	{
		h=sc.nextInt();
	}
	 void readLength()
	 {
		l=sc.nextInt();
	 }
	 void readBreadth()
	 {
		b = sc.nextInt();
	 }
	 void area()
	 {
		 System.out.println(0.5*b*h);
	 }
	 void perimeter()
	 {
		 System.out.println(l+b+h);
	 }
	 void countCorners()
	 {
		 System.out.println("3");
	 }
}
