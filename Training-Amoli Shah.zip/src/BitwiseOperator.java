import java.util.Scanner;

public class BitwiseOperator {
	Scanner sc = new Scanner (System.in);
	int v1,v2;
	public void read()
	{
		v1 = sc.nextInt();
		v2 = sc.nextInt();
	}
	public void bitAnd()
	{
		System.out.println("And "+(v1&v2));
	}
	public void bitOr()
	{
		System.out.println("Or "+(v1|v2));
	}
	public void shiftRight()
	{
		System.out.println("shiftRight "+(v1>>v2));
	}
	public void bitXor()
	{
		System.out.println("bitXor "+(v1^v2));
	}
	public void shiftRightZero()
	{
		System.out.println("shiftRightZero "+(v1>>>v2));
	}
	public void shiftLeft()
	{
		System.out.println("shiftLeft "+(v1<<v2));
	}
	public void bitAndAssignment()
	{
		System.out.println("bitAndAssignment "+(v1&=v2));
	}
	public void bitOrAssignment()
	{
		System.out.println("bitOrAssignment "+(v1|=v2));
	}
	public void bitXorAssignment()
	{
		System.out.println("bitXorAssignment "+(v1^=v2));
	}
	public void shiftRightAssignment()
	{
		System.out.println("shiftRightAssignment "+(v1>>=v2));
	}
	public void shiftRightZeroAssignment()
	{
		System.out.println("shiftRightZeroAssignment "+(v1>>>=v2));
	}
	public void shiftLeftAssignment()
	{
		System.out.println("shiftLeftAssignment "+(v1<<=v2));
	}
	public void bitNot()
	{
		System.out.println("Not "+(~v1));
	}
	
}
