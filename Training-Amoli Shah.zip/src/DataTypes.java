import java.util.Scanner;

public class DataTypes {
		
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int arr_size = sc.nextInt();
		char arr[] = new char[arr_size];
		int sum = 0;
		for(int i=0;i<arr_size;i++)
		{
			arr[i] = sc.next().charAt(0);
			sum = sum + arr[i];
		}
		System.out.println("Sum of chars is "+sum);
//		for(int i=arr_size-1;i>=0;i--)
//		{
//			System.out.println(arr[i]);
//		}
		
	}

}
