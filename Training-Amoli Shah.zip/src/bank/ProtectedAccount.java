package bank;

public class ProtectedAccount extends BasicAccount {
	int pin;
}
