package bank;

import java.util.Scanner;

public class BasicAccount {
	
	BasicAccount()
	{
		System.out.println("In s constructor");
	}
	BasicAccount(float minB,String actype)
	{
		float minbal = minB;
		
	}
String name;
	
	float int_rate;
	float currbal;
	Scanner sc = new Scanner(System.in);
	void checkBalance(float minbal,String ac)
	{
		readBalance();
		switch(ac)
		{
		
		case "sb":
			if(currbal < minbal)
			{
				float penalty = minbal * 0.10f;
				currbal = currbal - penalty;
				System.out.println("updated bal"+currbal);
			}
			break;
		case "ca":
			if(currbal < minbal)
			{
				float penalty = minbal * 0.15f;
				currbal = currbal - penalty;
				System.out.println("updated bal"+currbal);
			}
			
		}
		
	}
	public void readBalance()
	{
		System.out.println("Enter the available balance ");
		currbal = sc.nextFloat();
			
	}

}
