package bank;

public class RegularAccount {

}
