package bank;

public class CDAccount extends ProtectedAccount{
	float penalty;
	int months;
	float crnt_bal = 10000;
	
}
