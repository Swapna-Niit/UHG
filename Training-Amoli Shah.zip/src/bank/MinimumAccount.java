package bank;

public class MinimumAccount extends ProtectedAccount{
	float minBal = 1500.00f;
	String atype ="sb";
	public void checkAccount()
	{	
		
	}
	
}
