package bank;

public class MainBank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 float minbal = 1500.00f;
	 

	}

}
