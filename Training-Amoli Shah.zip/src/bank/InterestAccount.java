package bank;

public class InterestAccount extends ProtectedAccount{
}
