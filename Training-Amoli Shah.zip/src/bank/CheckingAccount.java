package bank;

public class CheckingAccount extends MinimumAccount {
	int transactions;
}
