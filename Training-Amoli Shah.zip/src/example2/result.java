package example2;

public class result extends marks {
	public result(int i, String string) {
		super(i, string);
		// TODO Auto-generated constructor stub
	}	
	 protected float total;
	void showResult()
	{
		 total = eng + math + sci + comp;
		System.out.println("The result is: " + total);
	}

}
