package example2;

public class mainexp extends result {

	public mainexp(int i, String string) {
		super(i, string);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		result s = new result(01,"Rama");
		s.addMarks(23.2f, 45, 58, 100);
		s.showResult();	

	}

}
