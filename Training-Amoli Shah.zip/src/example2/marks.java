package example2;

public class marks extends student {
	public marks(int i, String string) {
		super(i, string);
		// TODO Auto-generated constructor stub
	}
	protected float eng;
	protected float math;
	protected float sci;
	protected float comp;
	void addMarks(float a,float b,float c,float d)
	{
		eng = a;
		math = b;
		sci = c;
		comp = d;
	}
}
