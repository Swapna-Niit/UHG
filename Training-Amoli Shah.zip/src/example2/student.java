package example2;

public class student {
	public student(int i, String string) {
		// TODO Auto-generated constructor stub
		id = i;
		name = string;
	}
	public int id;
	public String name;

}
