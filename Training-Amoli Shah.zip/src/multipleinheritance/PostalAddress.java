package multipleinheritance;

public interface PostalAddress extends Address,City{
	void readPostalAddress();
}
