package multipleinheritance;

public class Courier implements PostalAddress {

	@Override
	public void readAddress() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readCity() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readPostalAddress() {
		// TODO Auto-generated method stub
		
	}

}
