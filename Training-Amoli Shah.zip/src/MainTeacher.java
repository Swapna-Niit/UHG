
public class MainTeacher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Teacher t = new Teacher(1, 2000);
		MathsTeacher mt = new MathsTeacher();
	}

}
