package string;

import java.util.Scanner;

public class Anagram {

	public static boolean checkAnagram(String word1,String word2) {

		word1 = word1.toLowerCase();
		word2 = word2.toLowerCase();
		int flag=1;
		int[] charArray = new int[26];
		for(int i=0;i<26;i++) {
			charArray[i]=0;
		}
		for(int i=0;i<word1.length();i++) {
			charArray[word1.charAt(i)-97]++;
		}
		for(int i=0;i<word2.length();i++) {
			charArray[word2.charAt(i)-97]--;
		}
		for(int i=0;i<26;i++) {
			if(charArray[i]>0) {
				flag=0;
				break;
			}
		}

		if(flag == 1  ) {
			return true;
		}else {
			return false;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter two words to be checked :");
		String word1 = scanner.next();
		String word2 = scanner.next();
		boolean check = checkAnagram(word1,word2);
		if(check) {
			System.out.println("Words are anagram");
		}else {
			System.out.println("Words are not anagram");
		}
		scanner.close();
	}

}
