package string;

import java.util.StringTokenizer;

public class StringReverse {

	public static String[] createTokens(String s) {
		StringTokenizer stringTokenizer = new StringTokenizer(s," ");
		String[] arrayStr = new String[stringTokenizer.countTokens()];
		int len=0;
		while(stringTokenizer.hasMoreElements()) {
			arrayStr[len] = stringTokenizer.nextToken();
			len++;
		}
		return arrayStr;

	}

	public static String[] printTokens(String[] array) {
		String[] newarray = new String[array.length];
		int index=0;
		while(index<array.length) {
			System.out.println("Actual Word : " + array[index]);
			int l = array[index].length();
			newarray[index]="";
			System.out.print("Reversed Word : " );
			for(int i=l-1;i>=0;i--) {
				System.out.print(array[index].charAt(i));
				newarray[index]+=array[index].charAt(i);
			}
			newarray[index]+=" ";
			System.out.println("");
			index++;
		}
		return newarray;
	}
	
	public static void main(String[] args) {
		String str = "This is a sample string.";
		String[] arrayStr = createTokens(str);
		arrayStr = printTokens(arrayStr);
		StringBuilder builder = new StringBuilder();
		for(String s : arrayStr) {
		    builder.append(s);
		}
		String newStr = builder.toString();
		System.out.println("Original String : " + str);
		System.out.println("Reversed String : " + newStr);
	}
}
