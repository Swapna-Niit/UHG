package string;

import java.util.StringTokenizer;

public class Sorting {

	public static String[] createTokens(String s) {
		StringTokenizer stringTokenizer = new StringTokenizer(s);
		String[] arrayStr = new String[stringTokenizer.countTokens()];
		int ind=0;
		while(stringTokenizer.hasMoreElements()) {
			arrayStr[ind] = stringTokenizer.nextToken();
			arrayStr[ind]+=" ";
			ind++;
		}
		return arrayStr;
	}
	
	public static String[] sort(String[] arrayStr) {
		for(int i=0;i<arrayStr.length;i++) {
			for(int j=0;j<arrayStr.length-1-i;j++) {
				if(arrayStr[j].compareTo(arrayStr[j+1])>0) {
					String temp = arrayStr[j];
					arrayStr[j]=arrayStr[j+1];
					arrayStr[j+1] = temp;
				}
			}
		}
		return arrayStr;
	}
	
	public static void main(String[] args) {
		String s = "this is a sample string";
		String[] array = createTokens(s);
		String[] arrayStr = sort(array);
		StringBuilder builder = new StringBuilder();
		for(String str : arrayStr) {
			builder.append(str);
		}
		String newStr = builder.toString();
		System.out.println("Original String : " + s);
		System.out.println("New String : " + newStr);

	}
}
