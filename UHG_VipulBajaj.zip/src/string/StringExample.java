package string;


import java.util.StringTokenizer;

public class StringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "hello world yh is is my first program for strings and strings sucks";
//		String s1 = new String();
//		String s2 = new String("Hi!Hello World");
//		char[] s3 = {'b','s','d','k'};
//		String s4 = new String(s3);
//		System.out.println(s1+s2+s4);
		
//		int[] intarray = new int[26];
//		for(int i=0;i<26;i++) {
//			intarray[i]=0;
//		}
//		for(int i=0;i<s.length();i++) {
//			//System.out.println(s.charAt(i)-97);
//			intarray[s.charAt(i)-97]++;
//		}
//		System.out.println("The duplicate Entries are : ");
//		for(int i = 0;i<26;i++) {
//			if(intarray[i]>1) {
//				System.out.print(Character.toChars(i+97));
//				System.out.print(",");
//			}
//		}
//		System.out.println("The duplicate words are : ");
//		String [] ss = s.split(" ");
//		for(int i = 0 ; i<ss.length;i++) {
//			for(int j= 0;j<ss.length;j++) {
//				if(ss[i].equals(ss[j]) && i!=j) {
//					System.out.println(ss[i]);
//				}
//			}
//		}
		
		StringTokenizer st = new StringTokenizer(s," ");
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}

	}

}