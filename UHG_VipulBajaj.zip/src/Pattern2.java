
public class Pattern2 {
	public static void main(String args[]) {
		int i,j,k,p=1,l=4;
		for(i=1;i<=5;i++) {
			for(j=l;j>0;j--) {
				System.out.print(" ");
			}
			for(k=1;k<=p;k++) {
				System.out.print(p);
			}
			p+=2;
			l--;
			System.out.println("");
		}
		
	}
}
