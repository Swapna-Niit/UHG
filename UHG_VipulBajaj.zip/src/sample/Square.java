package sample;

import java.util.Scanner;

public class Square extends Shape{
	public Square() {
		System.out.println("This is a constructor for square.");
	}
	void countCorners() {
		System.out.println("4 Corners");
	}
	int l,area,perimeter;
	Scanner scanner = new Scanner(System.in);
	@Override
	void readLength() {
		// TODO Auto-generated method stub
		l = scanner.nextInt();
	}

	@Override
	void area() {
		// TODO Auto-generated method stub
		area = l*l;
		System.out.println("Area of square = "+area);
	}

	@Override
	void perimeter() {
		// TODO Auto-generated method stub
		perimeter = 4*l;
		System.out.println("Perimeter of square = " + perimeter);
	}
}
