package sample;

public class Shape{
	
	public Shape() {
		System.out.println("This is a constructor for shape class.");
	}
	void readLength() {
		System.out.println("Length of Shape");
	}
	void readBreadth() {
		System.out.println("Breadth of Shape");
	}
	void area() {
		System.out.println("Area of Shape");
	}
	void perimeter() {
		System.out.println("Perimeter of Shape");
	}
	void countCorners() {
		System.out.println("Unpredictable");
	}
}