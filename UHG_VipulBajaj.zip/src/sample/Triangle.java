package sample;

import java.util.Scanner;

public class Triangle extends Shape{
	
	public Triangle() {
		System.out.println("This is a constructor for triangle.");
	}
	Scanner scanner = new Scanner(System.in);
	int l,b,h,perimeter;
	float area;
	void readLength() {
		l = scanner.nextInt();
	}
	void readBreadth() {
		b = scanner.nextInt();
	}
	void readHeight() {
		h = scanner.nextInt();
	}
	void countCorners() {
		System.out.println("3 Corners in Triangles");
	}
	void area() {
		area = 0.5f*b*h;
		System.out.println("Area of triangle = "+area);
	}
	void perimeter() {
		perimeter = l+b+h;
		System.out.println("Perimeter of triangle = " + perimeter);
	}
}
