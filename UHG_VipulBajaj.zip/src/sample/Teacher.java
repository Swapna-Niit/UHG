package sample;

public class Teacher {

	int teacherId,salary;
	void teaches() {
		System.out.println("Unknown");
	}
}
