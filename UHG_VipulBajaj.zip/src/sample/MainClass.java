package sample;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangle triangle = new Triangle();
		triangle.readLength();
		triangle.readBreadth();
		triangle.readHeight();
		triangle.area();
		triangle.perimeter();
	}

}
