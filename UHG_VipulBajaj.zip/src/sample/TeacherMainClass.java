package sample;

import java.util.Scanner;

public class TeacherMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the id and salary of the science teacher: ");
		int id = scanner.nextInt();
		int sal = scanner.nextInt();
		Science science = new Science(id,sal);
		science.teaches();
		System.out.println("Enter the id and salary of the computer science teacher: ");
		 id = scanner.nextInt();
		sal = scanner.nextInt();
		ComputerScience computerScience = new ComputerScience(id,sal);
		computerScience.teaches();
		scanner.close();
	}

}
