package sample;

public class Science extends Teacher{

	public Science(int id,int sal) {
		salary = sal;
		teacherId = id;
	}

	@Override
	void teaches() {
		System.out.println("Teacher teaches Science have " + teacherId + "as teacher Id and the salary is " + salary);
	}
	
}
