package sample;

public class ComputerScience extends Teacher {

	public ComputerScience(int id,int sal) {
		salary = sal;
		teacherId = id;
	}

	@Override
	void teaches() {
		// TODO Auto-generated method stub
		System.out.println("Teacher teaches Computer Science have " + teacherId + "as teacher Id and the salary is " + salary);
	}
	
	
}
