package bankingQuestion;

import java.util.Scanner;

public class BankAccount {

	String name;
	int accNumber = 10000001;
	float balance,intrestRate,penalty,minBalance;
	Scanner scanner = new Scanner(System.in);
	public BankAccount() {
		// TODO Auto-generated constructor stub
	}

	void openingAccount(int accountType) {
		System.out.println("Welcome to account opening portal.");
		System.out.println("Please provide the following details to open you new bank account :");
		System.out.println("Enter your Name : ");
		name = scanner.nextLine();
		switch(accountType) {
		case 1 : 	System.out.println("Enter opening balance (Minimum Balance:1500) : ");
		balance = scanner.nextFloat();
		if(balance<1500) {
			System.out.println("The opening balance cannot be less than 1500.\nExiting.");
		}
		break;
		case 2 : 	System.out.println("Enter opening balance (Minimum Balance:0) : ");
		balance = scanner.nextFloat();
		break;
		case 3 : 	System.out.println("Enter opening balance (Minimum Balance:10000) : ");
		balance = scanner.nextFloat();
		if(balance<10000) {
			System.out.println("The opening balance cannot be less than 1500.\nExiting.");
		}
		break;
		}

		System.out.println("Your new bank account has been created. The details are as follows :");
		System.out.println("Account Number = " + accNumber);
		System.out.println("Name = " + name);
		System.out.println("Current Balance = "+ balance);
		switch(accountType) {
		case 1 : 	System.out.println("Rate of Interes is 6% pa");
		break;
		case 2 : 	System.out.println("Rate of Interes is 5% pa");
		break;
		case 3 : 	System.out.println("Rate of Interes is 7% pa");
		break;
		}
		accNumber++;
	}

	void balanceCheck(int accountType) {
		switch(accountType) {
		case 1 :if(balance< 1500.0f) {
			System.out.println("The penalty imposed on your account is Rs." + 0.1f*balance);
			balance = balance -  0.1f*balance;
			System.out.println("The current balance in your account is Rs." + balance);
			}	
			System.out.println("The intrest calculated on your account is Rs." + 0.06f*balance);
			balance = balance+ 0.06f*balance;
			System.out.println("The current balance in your account is Rs." + balance);
			break;
		case 2 : 	System.out.println("The intrest calculated on your account is Rs." + 0.05f*balance);
		balance = balance+ 0.05f*balance;
		System.out.println("The current balance in your account is Rs." + balance);
		break;
		case 3 :if(balance<10000.0f) {
			System.out.println("The penalty imposed on your account is Rs." + 0.15f*balance);
			balance = balance -  0.15f*balance;
			System.out.println("The current balance in your account is Rs." + balance); 	
		}
		System.out.println("The intrest calculated on your account is Rs." + 0.07f*balance);
		balance = balance+ 0.07f*balance;
		System.out.println("The current balance in your account is Rs." + balance);
		break;
		}
	}

	void intrestCalculation() {

	}

	void penaltyCalculation() {

	}
}
