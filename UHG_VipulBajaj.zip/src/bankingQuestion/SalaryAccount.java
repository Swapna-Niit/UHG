package bankingQuestion;

public class SalaryAccount extends BankAccount {
	
	public SalaryAccount() {
		intrestRate = 0.05f;
	}


	@Override
	void intrestCalculation() {
		System.out.println("The intrest calculated on tyour account is Rs." + intrestRate*balance);
		balance = balance+ intrestRate*balance;
		System.out.println("The current balance in your account is Rs." + balance);
	}
	
	
	
}
