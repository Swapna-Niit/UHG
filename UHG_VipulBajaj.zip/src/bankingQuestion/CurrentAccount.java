package bankingQuestion;

public class CurrentAccount extends BankAccount {

	public CurrentAccount() {
		minBalance = 10000.00f;
		penalty = 0.15f;
		intrestRate = 0.07f;
	}

	
	@Override
	void intrestCalculation() {
		System.out.println("The intrest calculated on tyour account is Rs." + intrestRate*balance);
		balance = balance+ intrestRate*balance;
		System.out.println("The current balance in your account is Rs." + balance);
	}

	@Override
	void penaltyCalculation() {
		System.out.println("The penalty imposed on your account is Rs." + penalty*balance);
		balance = balance -  penalty*balance;
		System.out.println("The current balance in your account is Rs." + balance);
	}


}
