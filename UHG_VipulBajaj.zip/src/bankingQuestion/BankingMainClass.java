package bankingQuestion;

import java.util.Scanner;

public class BankingMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice,accountType;
		BankAccount bankAccount = new BankAccount();
		Scanner scanner = new Scanner(System.in);
		do{
			
			System.out.println("Main Menu:\n1.Opening Account\n2.Checking Balance\n3.Exit\nPlease enter your choice(1-3) : ");
			choice = scanner.nextInt();
			switch(choice) {
			case 1 :System.out.println("Main Menu:\n1.Saving Account\n2.Salary Account\n3.Current Account\nPlease enter your choice(1-3) : ");
			accountType = scanner.nextInt();
			bankAccount.openingAccount(accountType);
			break;
			case 2 :System.out.println("Main Menu:\n1.Saving Account\n2.Salary Account\n3.Current Account\nPlease enter your choice(1-3) : ");
			accountType = scanner.nextInt();
			bankAccount.balanceCheck(accountType);
			break;
			case 3 :System.exit(0);
			break;
			default : System.out.println("Error!! You have given an invalid account.");
			}
		}while(choice != 3);
		scanner.close();

	}

}
