package bankingExample;

public class CDAccount extends ProtectedAccount {
	double penalty,months;
}
