package bankingExample;

public class IntrestAccount extends ProtectedAccount {

}
