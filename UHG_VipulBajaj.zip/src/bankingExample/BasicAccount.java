package bankingExample;

public class BasicAccount {
	String name;
	double balance,rate;
}
