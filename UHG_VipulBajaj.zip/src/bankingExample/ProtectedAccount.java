package bankingExample;

public class ProtectedAccount extends BasicAccount{
	int pin;
}
