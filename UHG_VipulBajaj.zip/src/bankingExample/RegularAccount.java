package bankingExample;

public class RegularAccount extends MinimumAccount {

}
