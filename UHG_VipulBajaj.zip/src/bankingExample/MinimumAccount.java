package bankingExample;

public class MinimumAccount extends ProtectedAccount {
	double minimum,penalty;
}
