package bankingExample;

public class CheckingAccount extends MinimumAccount {
	
}
