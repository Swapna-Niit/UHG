import java.util.Scanner;

public class SpyNumber {
	public static void main(String ars[]) {
		int sum=0,prod=1;
		System.out.println("Please enter the number : ");
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		int n= num;
		while(num>0) {
			sum+=num%10;
			prod*=num%10;
			num = num/10;
		}
		if(sum == prod) {
			System.out.println("The given number " + n + " is a spy number");
		}else {
			System.out.println("The given number " + n + " is not a spy number");
		}
		scanner.close();
	}
}
