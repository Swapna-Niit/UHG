import java.util.Scanner;

public class AutomorphicNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please enter the number : ");
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		int sq = num*num;
		if((num%10) == sq%10) {
			System.out.println("The number is a automorphic number.");
		}
		else {
			System.out.println("The number is not a automorphic number.");
		}
		scanner.close();
	}

}
