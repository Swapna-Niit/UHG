package innerouter;

public class OuterClass {
	public class InnerClass {
		public void example() {
			System.out.println("Inside inner class");
		}
	}
	
	public static void main(String[] args) {
		OuterClass clas = new OuterClass();
		OuterClass.InnerClass clas1 = clas.new InnerClass(); 
		clas1.example();
		
	}
}
