import java.util.Scanner;

public class Addition {
	
	Scanner scanner = new Scanner(System.in);
	public void read() {
		System.out.println("Enter the first number : ");
		int num1 = scanner.nextInt();
		System.out.println("Enter the second number : ");
		int num2 = scanner.nextInt();
		add(num1,num2);
	}
	
	public void add(int num1,int num2) {
		System.out.println("The sum of " + num1 + " and " + num2 + " is " + (num1 + num2));		
	}

}
