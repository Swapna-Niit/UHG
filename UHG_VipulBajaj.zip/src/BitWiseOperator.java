import java.util.Scanner;

public class BitWiseOperator {
	Scanner scanner = new Scanner(System.in);
	int num1,num2,temp;
	public void read() {
		System.out.println("Enter the first number : ");
		num1 = scanner.nextInt();
		System.out.println("Enter the second number : ");
		num2 = scanner.nextInt();
		temp = num1;
	}
	
	public void bitAnd() {
		System.out.println("The bitwise AND of " + num1 + " and " + num2 + " is " + (num1 & num2));		
	}
	
	public void bitOr() {
		System.out.println("The bitwise OR of " + num1 + " and " + num2 + " is " + (num1 | num2));		
	}
	
	public void bitXor() {
		System.out.println("The bitwise XOR of " + num1 + " and " + num2 + " is " + (num1 ^ num2));		
	}
	
	public void bitNot() {
		System.out.println("The bitwise NOT of " + num1 + " is " + (~num1));
		num1=temp;
	}
	
	public void bitShiftRight() {
		System.out.println("The " + num1 + " after right shift is "+ (num1>>4));		
		num1=temp;
	}
	
	public void bitShiftLeft() {
		System.out.println("The " + num1 + " after left shift is "+ (num1<<4));		
		num1=temp;
	}
	public void bitShiftRightZeroFill() {
		System.out.println("The " + num1 + " after right shift zero fill is "+ (num1>>>1));		
		num1=temp;
	}
	public void bitAndAssignment() {
		System.out.println("The new value of " + num1 + " is " + (num1 &= num2));	
		num1=temp;
	}
	
	public void bitOrAssignment() {
		System.out.println("The new value of " + num1 + " is " + (num1 |= num2));
		num1=temp;
	}
	
	public void bitXorAssignment() {
		System.out.println("The new value of " + num1 + " is " + (num1 ^= num2));	
		num1=temp;
	}
	
	public void bitShiftRightAssignment() {
		System.out.println("The " + num1 + " after right shift is "+ (num1>>=4));		
		num1=temp;
	}
	
	public void bitShiftLeftAssignment() {
		System.out.println("The " + num1 + " after left shift is "+ (num1<<=4));		
		num1=temp;
	}
	public void bitShiftRightZeroFillAssignment() {
		System.out.println("The " + num1 + " after right shift zero fill is "+ (num1>>>=1));		
		num1=temp;
	}
}
