import java.util.Scanner;

public class DuplicatesInCharacterArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] array = new char[100];
		int[] intarray = new int[26];
		for(int i=0;i<26;i++) {
			intarray[i]=0;
		}
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the length of charcter array : ");
		int length = scanner.nextInt();
		System.out.println("Enter the elements of charcter array : ");
		for(int i=0;i<length;i++) {
			array[i] = scanner.next().charAt(0);
			//System.out.println(array[i]-97);
			intarray[array[i]-97]++;
		}
		System.out.println("The duplicate Entries are : ");
		for(int i = 0;i<26;i++) {
			if(intarray[i]>1) {
				System.out.println(Character.toChars(i+97));
			}
		}
		scanner.close();
	}
}
