
public class StaticDemo {
	static {
		System.out.println("Inside the static block");
	}
	void method() {
		@SuppressWarnings("unused")
		StaticDemo staticDemo = new StaticDemo();
	}
}
