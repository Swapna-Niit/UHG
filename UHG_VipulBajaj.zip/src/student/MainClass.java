package student;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		Result result[] = new Result[50];
		int i=0;
		char ch = 'Y';
		do {
			result[i] = new Result();
			System.out.println("Enter the student roll no :");
			result[i].rollNo = scanner.nextInt();
			System.out.println("Enter the student name :");
			result[i].sName = scanner.next();
			System.out.println("Enter the students maths marks :");
			result[i].mathsMarks = scanner.nextInt();
			System.out.println("Enter the students english marks ");
			result[i].engMarks = scanner.nextInt();
			System.out.println("Enter the students science marks ");
			result[i].sciMarks = scanner.nextInt();
			System.out.println("The student details are as follows :");
			System.out.println("Student Roll No : " + result[i].rollNo);
			System.out.println("Student Name : " + result[i].sName);
			System.out.println("Student Maths Marks : " + result[i].mathsMarks);
			System.out.println("Student English Marks : " + result[i].engMarks);
			System.out.println("Student Science Marks : " + result[i].sciMarks);
			System.out.println("Result : " + result[i].calculateResult());
			System.out.println("Want to enter more(y|n) : " );
			ch = scanner.next().charAt(0);
			i++;
		}while(ch !='n' || ch!='N');
		scanner.close();
	}

}
