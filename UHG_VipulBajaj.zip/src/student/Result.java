package student;

public class Result extends Marks {
	private float result;
	float calculateResult() {
		result = (mathsMarks + engMarks + sciMarks)/3;
		//System.out.println("The student has secured " + result + "%.");
		return result;
	}
}
