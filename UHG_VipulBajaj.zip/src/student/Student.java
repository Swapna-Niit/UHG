package student;

public class Student {
	String sName;
	int rollNo;
}
