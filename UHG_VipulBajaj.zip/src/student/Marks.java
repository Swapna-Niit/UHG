package student;

public class Marks extends Student {
	protected int mathsMarks,engMarks,sciMarks;
}
