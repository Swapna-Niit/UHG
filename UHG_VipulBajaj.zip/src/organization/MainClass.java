package organization;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee eArray[] = new Employee[100];
		Department dArray[] = new Department[25];
		int choice,i=0,j=0;
		Scanner scanner = new Scanner(System.in);
		do {
			System.out.println("Main Menu\n1.Create Employee\n2.Create Department\n3.Display Employee\n4.display Departments\n5.Exit\nEnter your choice(1-3) :");
			choice = scanner.nextInt();
			switch(choice) {
			case 1:eArray[i] = new Employee();
				System.out.println("Enter the employee id : ");
			eArray[i].seteID((scanner.nextInt()));
			System.out.println("Enter the employee name : ");
			String name = scanner.next();
			eArray[i].seteName(name);
			System.out.println("Enter the employee salary : ");
			eArray[i].seteSalary((scanner.nextInt()));
			System.out.println("The employee has been created successfully.");
			i++;
			break;
			case 2:dArray[j] = new Department();
				System.out.println("Enter the department id : ");
			dArray[j].setdId((scanner.nextInt()));
			System.out.println("Enter the department name : ");
			dArray[j].setdName((scanner.next()));
			System.out.println("The department has been created successfully.");
			j++;
			break;
			case 3 :for(int p=0;p<i;p++) {
				System.out.println("The employee details are as follows:");
				System.out.println("Employee Id : " + eArray[p].geteID());
				System.out.println("Employee Name : " + eArray[p].geteName());
				System.out.println("Employee Salary : " + eArray[p].geteSalary());
			}
			break;
			case 4 :for(int p=0;p<j;p++) {
				System.out.println("The department details are as follows:");
				System.out.println("Department Id : " + dArray[p].getdId());
				System.out.println("Department Name : " + dArray[p].getdName());
			}
			break;
			case 5 :System.exit(0);
			}
		}while(choice !=5);
		scanner.close();
	}

}
