
public class DataTypes {

	public static void main(String[] args) {
		int i=10;
		float fl=123.456f;
		double d = 123456.7879;
		char ch = 'a';
		short s=327;
		byte b =127;
		boolean bool = true;
		long l = 321456987l;
		System.out.println("Integer = " + i);
		System.out.println("Float = "+fl);
		System.out.println("Double = "+d);
		System.out.println("Character = " + ch);
		System.out.println("Short = " + s);
		System.out.println("byte = " + b);
		System.out.println("Boolean = " + bool);
		System.out.println("long = " + l);
		System.out.println(2*3/4+4/4+8-2+5/8);
		System.out.println(((3/2)*4)+3/8+3);
	}

}
