
public class Pattern {

	public static void main(String[] args) {
		int i,j,k=5;
		for(i=0;i<10;i++) {
			if(i<5) {
				for(j=k;j>0;j--) {
					System.out.print("*");
				}
				k--;
				System.out.println("");
			}
			else {
				//System.out.println(i + "," + k);
				for(j=0;j<k+1;j++) {
					System.out.print("*");
				}
				k++;
				System.out.println("");
			}
		}
	}
}
