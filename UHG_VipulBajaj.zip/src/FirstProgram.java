import java.util.Scanner;

public class FirstProgram{
	public static void main(String[] args){
//		int array[] = new int[5];
//		int sum = 0;
//		System.out.println("Enter the values for array :");
//		Scanner scanner = new Scanner(System.in);
//		for(int i=0;i<5;i++) {
//			array[i] = scanner.nextInt();
//			sum += array[i];
//		}
//		System.out.println("Sum of the elements of array = " + sum);
		
		char array[] = new char[25];
		int i = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the characters (. to teriminate):");
		do {
			array[i] = scanner.next().charAt(0);
			i++;
		}while (array[i-1] !='.');
		i=i-2;
		
		int sum=0;
		
		while(i >= 0) {
			sum += array[i];
			i--;
		}
		
		System.out.println("The sum of characters entered = " + sum);
		scanner.close();
	}
}