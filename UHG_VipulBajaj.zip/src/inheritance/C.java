package inheritance;

public class C extends B {

	@Override
	void printInfo() {
		// TODO Auto-generated method stub
		super.printInfo();
		System.out.println("In class C method");
		
	}

}
