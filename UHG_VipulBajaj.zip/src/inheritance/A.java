package inheritance;

public class A {
	void printInfo() {
		System.out.println("In A class method.");
	}
}
