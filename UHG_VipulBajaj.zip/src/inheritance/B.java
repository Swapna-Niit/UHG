package inheritance;

public class B extends A {

	@Override
	void printInfo() {
		// TODO Auto-generated method stub
		System.out.println("In class B method");
	}
	
	void printInfo(String s) {
		System.out.println("String : " + s);
	}
}
