
/**
 * @author Vipul Bajaj
 *
 */

public class ArithematicOperation {

	public static void main(String[] args) {
		BitWiseOperator bitWiseOperator = new BitWiseOperator();
		bitWiseOperator.read();
		bitWiseOperator.bitAnd();
		bitWiseOperator.bitOr();
		bitWiseOperator.bitNot();
		bitWiseOperator.bitXor();
		bitWiseOperator.bitShiftRight();;
		bitWiseOperator.bitShiftLeft();
		bitWiseOperator.bitShiftRightZeroFill();
		bitWiseOperator.bitShiftRightAssignment();
		bitWiseOperator.bitShiftLeftAssignment();
		bitWiseOperator.bitShiftRightZeroFillAssignment();
		bitWiseOperator.bitAndAssignment();
		bitWiseOperator.bitOrAssignment();
		bitWiseOperator.bitXorAssignment();
	}
}
