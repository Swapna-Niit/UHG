package interfaces;

public interface DataBase {
	void connectDB();
	default void connectionValues() {
		System.out.println("Details of the uername and password");
	}
	static void values() {
		System.out.println("In static method");
	}
}
