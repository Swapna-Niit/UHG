package interfaces;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataBaseImplement dataBaseImplement = new DataBaseImplement();
		dataBaseImplement.connectionValues();
		dataBaseImplement.connectDB();
		DataBase.values();
	}

}
