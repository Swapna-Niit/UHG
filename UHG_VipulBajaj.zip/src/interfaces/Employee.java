package interfaces;

public class Employee {
	public static int empId = 123456;
	void readEmpId() {
		System.out.println("employee id = " + empId);
	}
}
