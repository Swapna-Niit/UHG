package interfaces;

public class DataBaseImplement implements DataBase {

	@Override
	public void connectDB() {
		// TODO Auto-generated method stub
		System.out.println("Connecting to DB");
	}

}
