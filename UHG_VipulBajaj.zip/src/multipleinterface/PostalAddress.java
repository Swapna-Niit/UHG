package multipleinterface;

public interface PostalAddress extends Address, City {
	public void readPostalAddress() ;
}
