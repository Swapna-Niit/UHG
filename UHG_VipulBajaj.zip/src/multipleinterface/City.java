package multipleinterface;

public interface City {
	public void readCity() ;
}
