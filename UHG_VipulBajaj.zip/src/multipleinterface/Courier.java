package multipleinterface;

public class Courier implements Address,City,PostalAddress{

	int m;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		boolean b1=true,b2=false;
		System.err.println((b1=false) );
		if((b1=false) | (b1^b2)) {
			System.out.println("Success");
		}
	}

	@Override
	public void readPostalAddress() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readCity() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readAddress() {
		// TODO Auto-generated method stub
		
	}
	
	

}
