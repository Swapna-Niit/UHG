package multipleinterface;

public interface Address {
	public void readAddress() ;
}
