package journey;

public class Car extends Vehicle {
	public static void KmintoMiles(int km) {
		System.out.println("Inside Car Class Kms driven : " + km);
	}
}
