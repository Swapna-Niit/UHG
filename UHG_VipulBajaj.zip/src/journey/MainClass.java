package journey;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle car = new Car();
		System.out.println(car instanceof Vehicle);
		Vehicle.KmintoMiles(500);
	}

}
