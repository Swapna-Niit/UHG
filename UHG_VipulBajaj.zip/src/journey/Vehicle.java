package journey;

public class Vehicle {
	public static void KmintoMiles(int km) {
		System.out.println("Inside Vehicle Class Kms driven : " + km);
	}
}
