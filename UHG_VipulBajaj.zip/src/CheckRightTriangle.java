import java.util.Scanner;

public class CheckRightTriangle {
	
	public static void main(String args[]) {
		System.out.println("Enter the three angles :");
		Scanner scanner = new Scanner(System.in);
		int ang1,ang2,ang3;
		ang1 = scanner.nextInt();
		ang2 = scanner.nextInt();
		ang3 = scanner.nextInt();
		if(ang1 == 0 || ang2 == 0 || ang3 == 0) {
			System.out.println("The given angles donot form a right angled triangle.");
		}
		if((ang1 + ang2 == 90 && ang3 == 90) || (ang1 + ang3 == 90 && ang2 == 90) || (ang3 + ang2 == 90 && ang1 == 90)) {
			System.out.println("The given angles forms a right angled triangle.");
		}
		else {
			System.out.println("The given angles donot form a right angled triangle.");
		}
		scanner.close();
	}

}
