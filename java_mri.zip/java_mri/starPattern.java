package sample;

public class starPattern {
	public static void main(String[] args){
		int i,j;
		
		for(j=5;j>0;j--){
			for(i=0;i<j;i++){
			System.out.print("* ");
			
			}
			System.out.println("");
			

	}
		for(j=1;j<=5;j++){
			for(i=0;i<j;i++){
				System.out.print("* ");
			}
			System.out.println("");
		}

}
}
