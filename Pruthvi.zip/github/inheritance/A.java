package inheritance;

public class A
{
	int var1=200;
 A()
	{
		System.out.println("this is class A");
	}

	public static void main(String[] args)
	{ B b=new B();
		b.printinfo();
		A a=new A();
	}
}
