package inheritance;

public class B extends A 
{

int var=200;
void printinfo()
{
	System.out.println("this is class B");
	System.out.println("sum = "+ (this.var+var1));
}
	
}
