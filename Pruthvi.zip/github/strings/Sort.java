package strings;
import java.util.Scanner;

import java.util.StringTokenizer;

public class Sort
{

	
	
	Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
	Sort so=new Sort();
	String s=new String();
	s=so.read();
	StringTokenizer st=new StringTokenizer(s," ");
	//so.tokenss(st);
	
	
	
	so.sorts(st);
		
	}
	
	public String read()
	{
		System.out.println("enter the string");
		String str=sc.nextLine();
		return str;
		
	}
	
	/*void tokenss(StringTokenizer st)
	{
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken());
		}
	}*/
	
	
	public void sorts(StringTokenizer st1)
	{
		char ch[]=st1.nextToken().toCharArray();
		for(int i=(ch.length)-1;i>=0;i--)
		{
			
			System.out.println(ch[i]);
		}
		
	}

}
