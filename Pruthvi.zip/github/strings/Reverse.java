package strings;


public class Reverse {
	
	public static void main(String[] args) {
		String s= "hello world";
		Reverse rv=new Reverse();
		
		
		rv.reverse(s);

	}
	
	void reverse(String s)
	{
	int len=s.length();	
	char ch[]=s.toCharArray();
	for(int i=len-1;i>=0;i--)
	{
		
		System.out.print(ch[i]);
		
	}
	
	}
	}
	
	
