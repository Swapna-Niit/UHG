package strings;
import java.util.StringTokenizer;

public class Program 
{


    void write(String s)
    {
    	System.out.println(s);
    }
    
   void tokenss()
   {
	   StringTokenizer st = new StringTokenizer("my name is pruthvi"," ");
	   while (st.hasMoreTokens()) {  
	         System.out.println(st.nextToken()); } 
		
   }
	
	
	
	public static void main(String[] args) 
	{
		Program pr=new Program();
		String s=new String("this is java programming");
		pr.write(s);
		 
		 pr.tokenss();
	     

	}


  
}