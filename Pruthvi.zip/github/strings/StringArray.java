package strings;
import java.util.Scanner;

public class StringArray {

	public static void main(String[] args) {
		int i;
		Scanner sc = new Scanner(System.in);
		String s=new String();
		System.out.println("enter the string");
		s=sc.nextLine();
		String arr[]=s.split(" ");
		System.out.println(arr.length);
		int[] count=new int[1000];
		for(i=0;i<arr.length;i++)
		{
			++count[(int)arr.length];
		}
		if(count[(int)arr.length]>1)
			{System.out.println("Duplicate found!");
		System.out.println("duplicate is found @ "+ (i+1) + "th position " + "repeated for " + count[(int)arr.length] + " times" );}
		else
			System.out.println("no duplicates");
	}

}
