package strings;
import java.util.Scanner;

public class StrPrgrm {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in); 
		
		System.out.println("enter the string");
		String s1=new String(sc.nextLine());
		char ch[]=s1.toCharArray();
		int csize;
		csize=s1.length();
		
		int[] cnt=new int[1000];
		for(int i=0;i<csize;i++)
		{
			++cnt[(int)ch[i]];
			if(cnt[(int)ch[i]]>1)
			{   
				System.out.println("duplicate found");
				System.out.println("the letter "+ ch[i] + "is repeated "+ cnt[(int)ch[i]] + " number of times at "+ (i+1) + "th position");
			}
		
			else
			{System.out.println("no duplicate found");}
		
			
		
		
		}
		
}
}