import java.util.Scanner;
public class Automorphic {
	public static void main(String[] args)
	{
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		n=sc.nextInt();
		int sum=0,pro=1;
		while(n!=0)
		{ 
			int r=n%10;
			sum=sum+r;
			pro=pro*r;
			n=n/10;
		}
		if(sum==pro)
			System.out.println("it is automorphic");
		else
			System.out.println("not automorphic");
		
	}
	

}
