import java.util.Scanner;
class BitwiseOperator {
	Scanner sc=new Scanner(System.in);
	int val1,val2,tval1,tval2;
	void read()
	{
		System.out.println("enter two values");
		val1=sc.nextInt();
		val2=sc.nextInt();
		
	}

	public void bitand()
	{
		System.out.println("AND of two numbers is"+ (val1&val2));
	}
	public void bitor()
	{
		System.out.println("OR of two numbers is"+ (val1|val2));
	}
	public void bitexor()
	{
		System.out.println("EXOR of two numbers is"+ (val1^val2));
	}
	public void bitnot()
	{
		System.out.println("NOT of first numbers is"+ ~val1);
		System.out.println("NOT of second numbers is"+ ~val2);
	}
	public void shiftright()
	{
		System.out.println("RIGHT SHIFT of first numbers is"+ (tval1>>val1));
		System.out.println("RIGHT SHIFT of second numbers is"+ (tval2>>val2));
	}
	public void shiftleft()
	{
		System.out.print("LEFT SHIFT of first numbers is"+ (tval1<<val1));
		System.out.println("LEFT SHIFT of second numbers is"+ (tval2<<val2));
	}
	
}
