package arrrrayy;

public class ArrayClass {
	int grocnum;
	String grocname;
	float grocprice;
	ArrayClass(int a,String b,float c)
	{
		grocnum =a;
		grocname = b;
		grocprice = c;
		System.out.println( grocnum+" "+ grocname+ " "+ grocprice );
		
		
	}

	public static void main(String[] args) {
		
		ArrayClass[] a=new ArrayClass[2];
		a[0]=new ArrayClass(1,"green gram",50.50f);
		a[1]=new ArrayClass(2,"horse gram",30.50f);
		
		
	}

}
