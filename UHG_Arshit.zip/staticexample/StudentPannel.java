package staticexample;

import java.util.Scanner;

public class StudentPannel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("No Of Student : ");
		int size = sc.nextInt();
		Result s1[] = new Result[size];
		for(int i=0;i<size;i++){
			s1[i] = new Result();
			System.out.println("Student ID : ");
			int id = sc.nextInt();
			System.out.println("Student Name : ");
			String name = sc.next();
			System.out.println("Physics Marks : ");
			int p = sc.nextInt();
			System.out.println("Chemistry Marks : ");
			int c = sc.nextInt();
			System.out.println("Maths Marks : ");
			int m = sc.nextInt();
			s1[i].setDetails(id, name);
			s1[i].setMarks(p, c, m);
			s1[i].avgMarks();
			s1[i].displayResult();
			s1[i].displayDetails();
			s1[i].totalMarks();		
		}
		
		

	}

}
