package staticexample;

import java.util.Scanner;

public class Department {
	
	int did;
	String name;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		Department arr[] = new Department[size];
		for(int i=0;i<size;i++){
			
			System.out.println("\n Id : ");
			arr[i].did = sc.nextInt();
			System.out.println("\n Name : ");
			arr[i].name = sc.nextLine();
		}

	}

}
