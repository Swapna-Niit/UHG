package staticexample;

public class Student {
	public int grn;
	public String name;
	
	void setDetails(int id,String name){
		grn = id;
		this.name = name;
		
	}
	
	void displayDetails(){
		System.out.println("GRN No. : "+grn+"Student Name : "+name);
	}

}
