package staticexample;

public class Vehicle {
	static public void name(){
			
			System.out.println("in vehicle");
	}
}
