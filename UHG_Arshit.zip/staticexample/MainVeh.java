package staticexample;
import static java.lang.Integer.MAX_VALUE;
import java.util.*;

public class MainVeh {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle v = new Car();
		System.out.println(v instanceof Car);
		v.name();

	}

}
