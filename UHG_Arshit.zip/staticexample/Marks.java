package staticexample;

public class Marks extends Student {
	
	private int phy,che,maths;
	
	void setMarks(int p ,int c, int m){
		phy = p;
		che = c;
		maths = m;
	}
	
	float totalMarks(){
		float total = phy+che+maths;
		return total;
	}
	
	float avgMarks(){
		float total = (phy+che+maths)/3;
		System.out.println("Avg  "+total);
		return total;
	}

}
