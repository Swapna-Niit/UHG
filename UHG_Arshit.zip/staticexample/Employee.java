package staticexample;
import java.util.*;

public class Employee {
	
	int id,sal;
	String name;
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		Employee arr[] = new Employee[size];
		for(int i=0;i<size;i++){
			arr[i] = new Employee();
			System.out.println("\n Id : ");
			arr[i].id = sc.nextInt();
			System.out.println("\n Name : ");
			arr[i].name = sc.next();
			System.out.println("\n Salary : ");
			arr[i].sal = sc.nextInt();
		}
		
	}

}

