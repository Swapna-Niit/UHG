package staticexample;

public class Car extends Vehicle{
	static public void name(){
		
		System.out.println("in Car");
}
	public void ne(){
		
		System.out.println("in vehicle");
}

}
