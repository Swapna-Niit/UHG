package first;

public class Square extends Triangle{
	
	
	Square(){
		
		
	}
	
	Square(float len,float bred){
		l=len;
		b=bred;
	}
	void readLength(){
		//System.out.println("Length of shape");
		l = sc.nextInt();
	}

	void readHeight(){
		System.out.println("Height of Square");
		h = sc.nextInt();
	}
	void CountCorners(){
		System.out.println("4 Corners");
	}
	void area(){
		//System.out.println("3 Corners");
		System.out.println(l*b);
	}

}
