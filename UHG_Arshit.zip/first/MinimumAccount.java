package first;

public class MinimumAccount extends ProtectedAccount {
	int mini=5000,pen=10;
	double p_amt;
	MinimumAccount(String s,int bl,float d,int p){
		super(s,bl,d,p);
		
	}
	
	public double  penalty(){
		if(bal <= mini)
			p_amt = ((mini-bal)*pen)/(float)100;
		else
			p_amt = 0.00;
		
		return p_amt;
	}
	
	void display(){
		System.out.println("Sub Sub Class");
	}
	void check(){
		super.display();
	}	

}
