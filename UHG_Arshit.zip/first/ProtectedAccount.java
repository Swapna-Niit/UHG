package first;

public class ProtectedAccount extends BasicAccount {
	int pin;
	ProtectedAccount(String n,int bl,float rate,int p){
		super(n,bl,rate);
		pin = p;
		
	}
	void display(){
		System.out.println("Sub Class");
	}
	

}
