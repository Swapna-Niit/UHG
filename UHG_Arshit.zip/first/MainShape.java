package first;

public class MainShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Triangle t = new Triangle();

	}

}
