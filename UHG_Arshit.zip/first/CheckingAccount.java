package first;

public class CheckingAccount extends MinimumAccount {
	private int trans;
}
