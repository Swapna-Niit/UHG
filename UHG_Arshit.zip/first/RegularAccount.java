package first;

public class RegularAccount extends MinimumAccount {

}
