package first;
import java.util.*;

public class Examples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		//-----------CHAECK TRIANGLE
//		int a,b,c;
//		a = sc.nextInt();
//		b = sc.nextInt();
//		c = sc.nextInt();
//		if((a+b+c) == 180 ){
//			if(a==90 || b==90 || c==90)
//				System.out.println("True");
//			else
//				System.out.println("False");
//		}
//		else
//			System.out.println("Not Valid");
		
		//D--------------------DUPLICATE CHARECTERS
		
//		int size = sc.nextInt();
//		char ch[] = new char[size];
//		int dup[] = new int[26];
//		for(int i=0;i<size;i++){
//			ch[i] = sc.next().charAt(0);
//			if(dup[ch[i]-65] == 1)
//				System.out.println(ch[i]);
//			else
//			dup[ch[i]-65] = 1;
//		
//		}
		
		//---------------------------------pattern
		
	
//		for(int i=0;i<=5;i++){
//			for(int j=0;j<=i;j++){
//				System.out.print(" "+m);
//			}
//			System.out.println("");
//		}
		
		////-------------------spy number
		
//		int num = sc.nextInt();
//		int digitSum=0,digitMul=1;
//		while(num>0){
//			digitSum+=num%10;
//			digitMul *= num%10;
//			num = num/10;
//			
//		}
//		if(digitSum  ==  digitMul)
//			System.out.print("True");
//		else
//			System.out.print("False");
//		
		//----------------Automorphic number
		
//		int num = sc.nextInt();
//		int sq = num*num;
//		String str_num = Integer.toString(num);  
//        String sq_str = Integer.toString(sq);  
// 
//        if(sq_str.endsWith(str_num))  
//            System.out.println("Automorphic Number.");
//        else
//            System.out.println("Not an Automorphic Number.");
//    
//		
		
		
	}

}
