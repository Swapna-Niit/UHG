package first;

public class InterestAccount extends ProtectedAccount {

	InterestAccount(String s,int bl,float rate,int p){
		super(s,bl,rate,p);
		
	}
	
	public double calculateIntAmt(){
		float amt = bal*int_rate;
		
		return amt;
	}
	

}
