package first;

public class Shape {
	
	Shape(){
		System.out.println("Constroctor of Shape");
	}
	
	void readLength(){
		System.out.println("Length of shape");
	}
	
	void readBreadth(){
		System.out.println("Breadth of Shape");
	}
	
	void area(){
		System.out.println("Area of Shape");
	}
	
	void parameter(){
		System.out.println("Parameters of Shape");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
