package first;

public class Teacher {
	
	int tId,tSal;
	Teacher(int id, int sal){
		tId = id;
		sal = tSal;
	}
	
	void display(){
		System.out.println("Teacher Id = "+tId+" Salary "+tSal);
	}

}
