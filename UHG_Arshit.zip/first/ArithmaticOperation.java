package first;

public class ArithmaticOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BitwiseOperator bo =  new BitwiseOperator();
		bo.bitAnd();
		bo.bitAndAssign();
		bo.bitExclosiveOrAssign();
		bo.bitExclusiveOr();
		
	}

}
