package first;
import java.util.*;

public class SortArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MinimumAccount m = new MinimumAccount("Arshit",2345,0.1f,34);
		m.check();
	}

}
