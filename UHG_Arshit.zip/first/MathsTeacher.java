package first;

public class MathsTeacher extends Teacher {
	int depno;
	MathsTeacher(int id,int sal,int depNO){
		super(id,sal);
		depno = depNO;
	}
	
	void display(){
		System.out.println("Maths Teacher Id = "+tId+" Salary "+tSal+"Dept Id"+depno);		
	}

}
