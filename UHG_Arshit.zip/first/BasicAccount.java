package first;

public class BasicAccount {
    String name;
	int bal;
	float int_rate;
	
	BasicAccount(String n,int bl,float rate){
		name = n;
		bal = bl;
		int_rate = rate;
	}
	
	void display(){
		System.out.println("Super Class");
	}
	

}
