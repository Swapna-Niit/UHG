package first;

public class Physics extends Teacher {
	int depno;
	
	Physics(int id,int sal,int depNO){
		super(id,sal);
		depno = depNO;
	}
	
	void display(){
		System.out.println("Physics Teacher Id = "+tId+" Salary "+tSal+"Dept Id"+depno);		
	}

}
