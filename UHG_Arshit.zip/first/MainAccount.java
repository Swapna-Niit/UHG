package first;
import java.util.*;

public class MainAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\n 1.Create Basic Account. \n 2. Create Interest Account \n 3. Create CDAccount \n 4. Calculate Interest for your Account. \n");
		Scanner sc = new Scanner(System.in);
		int ch = sc.nextInt();
		String cname = sc.nextLine();
		int salary = sc.nextInt();
		float irate = sc.nextFloat();
		int pins = sc.nextInt();
		
		switch(ch){
		
		case 1:
		
		
		
		
		
		}
		MinimumAccount m = new MinimumAccount(cname,salary,irate,pins);
		System.out.println("Penalty = "+ m.penalty());
	}

}
