package first;

public class CDAccount extends ProtectedAccount {
 int pen,months;
 int p = 10000;
	CDAccount(String s,int bl,float rate,int p){
		super(s,bl,rate,p);
		
	}
	
	public double  penalty(){
		float p_amt;
		if(bal <= p)
			p_amt = ((p-bal)*pen)/(float)100;
		else
			p_amt = 0f;
		
		return p_amt;
	}
	

}
