package first;

public class TeacherList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Physics p = new Physics(1,34000,3);
		MathsTeacher m = new MathsTeacher(2,34000,5);

	}

}
