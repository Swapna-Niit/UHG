package first;
import java.util.*;

public class BitwiseOperator {
	int val1,val2;
	Scanner sc = new Scanner(System.in);
	
	public void read(){
		val1 = sc.nextInt();
		val2 = sc.nextInt();
	}
	
	public void bitAnd(){
		System.out.println("Bitwise AND is : "+ (val1 & val2));
	}
	
	public void bitNot(){
		System.out.println("Bitwise NOT is : "+ (val1 & ~val2));
	}
	
	public void bitOr(){
		System.out.println("Bitwise OR is : "+ (val1 | val2));
	}
	public void bitExclusiveOr(){
		System.out.println("Bitwise Exclusive OR is : "+ (val1 ^ val2));
	}
	
	public void bitShiftRight(){
		System.out.println("Bitwise >> is : "+ (val1 >> val2));
	}
	public void bitShiftRightZero(){
		System.out.println("Bitwise >>> is : "+ (val1 >>> val2));
	}
	
	public void bitLeft(){
		System.out.println("Bitwise << is : "+ (val1 << val2));
	}
	
	public void bitAndAssign(){
		System.out.println("Bitwise &= is : "+ (val1 &= val2));
	}
	public void bitOrAssign(){
		System.out.println("Bitwise |= is : "+ (val1 |= val2));
	}
	public void bitExclosiveOrAssign(){
		System.out.println("Bitwise ^= is : "+ (val1 ^= val2));
	}
	public void bitShiftRightAssign(){
		System.out.println("Bitwise >>= is : "+ (val1 >>= val2));
	}
	public void bitShiftRightZeroAssign(){
		System.out.println("Bitwise >>>= is : "+ (val1 >>>= val2));
	}
	public void bitShiftLeftAssign(){
		System.out.println("Bitwise <<= is : "+ (val1 <<= val2));
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub


	}

}
