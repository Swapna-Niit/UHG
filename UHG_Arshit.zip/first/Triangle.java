package first;
import java.util.*;

public class Triangle extends Shape {
	
		float l,b,h;
		Scanner sc = new Scanner(System.in);
	
		void readLength(){
			//System.out.println("Length of shape");
			l = sc.nextInt();
		}

		void readHeight(){
			System.out.println("Height of triangle");
			h = sc.nextInt();
		}
		void CountCorners(){
			System.out.println("3 Corners");
		}
		void area(){
			System.out.println("3 Corners");
		}
}
