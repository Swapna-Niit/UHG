package first;
import java.util.*;
public class Addition {
	int fvalue,svalue;
	Scanner sc = new Scanner(System.in);
	/**
	 * Addition of two values
	 */
	public void add(){
		System.out.println("Addition of value is " + (fvalue+svalue));
		
	}
	
	/**
	 * Reading value from user
	 */
	
	public void read(){
		System.out.println("Enter First Value :");
		fvalue = sc.nextInt();
		System.out.println("Enter Second Value :");
		svalue = sc.nextInt();
		
	}
	

}
