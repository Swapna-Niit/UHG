package first;

public class AccessModifier {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=0;i<10;i++){
			for(int j=0;j<5;j++){
				
				if(i<=j)
				System.out.print("* ");
				else if(i>=5)
					if((j+5) <=i)
						System.out.print("* ");
			}
			System.out.println("");
		}

	}

}
