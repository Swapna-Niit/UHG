package first;
import java.util.*;
public class DataTypes {

	public static void main(String[] args) {
		/* TODO Auto-generated method stub */
//int a=1,b=1,c=1,m=2,q=3,r=3,v=2,d=4,g=3,x=3,y=2;
//		double result;
//		result = (8.8*(a+b)*2/c - 0.5 + 2*a/(q+r))/((a+b)*(1/m));	
//		System.out.print(result);
//		result = (-b+(b*b)+2.4*a*c)/2*a;
//		System.out.print(result);
//		result = ( 2*v + 6.22*(c+d) )/(g+v);
//		System.out.print(result);
//		result = (7.7*b*(x*y+a)/c-0.8+2*b)/((x+a)*(1/y));
//		System.out.print(result);
//		
//		System.out.print(result);    
//		
		
		//int a[] = new int[5];
//		char ch[] = {'a','b'};
		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter number");
//		int a = sc.nextInt();
//		int b = sc.nextInt();
//		System.out.println(a+b);
//		sc.close();
		
	int asize = sc.nextInt();
	int sum=0;
	int arr[] = new int[asize];
//	for(int i=0;i<asize;i++){
	int i = asize;
	while(i>=0){
		System.out.println("Enter the " + i+" Element : ");
		arr[i] = sc.nextInt();
		sum+=arr[i];
	}
//	System.out.println("Total sum = "+sum);
//		char arr[] = new char[asize];
//		for(int i=0;i<asize;i++){
//			arr[i] = sc.next().charAt(0);
//			sum+=arr[i];
//		}
//	
//	System.out.println("Total sum = "+sum);
		
	


		
	}

}
