package inheritance;

public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = new A();
		B b  = new B();
		C c = new C();
		c.display();
		b.display();
		a.display("Arshit");

	}

}
