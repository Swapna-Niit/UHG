package inheritance;

public class C extends B {
	void display(){
		super.display();
		System.out.println("C Class");
	}
}
