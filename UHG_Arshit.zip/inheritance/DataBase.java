package inheritance;

public interface DataBase {
	int a=30;
	public void connectDB();
	default void connectDataBase(){
		System.out.println("Default");
		
	}
	static void values(){
		System.out.println("Static");
	}

}
