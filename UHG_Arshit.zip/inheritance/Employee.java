package inheritance;

public class Employee {
	static int empid=34;
	int sal=345;
	static void readEmpId(){
		System.out.println(empid);
	}
	 void readSal(){
		System.out.println(sal);
	}
	 
	 public static void main(String[] args) {
			// TODO Auto-generated method stub
			Employee em = new Employee();
			em.empid=10;
		}
	

}
