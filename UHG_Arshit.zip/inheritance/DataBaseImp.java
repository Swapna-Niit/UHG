package inheritance;

public class DataBaseImp implements DataBase{
	
	public void connectDB(){
		
		System.out.println("Interface Implemented");
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	

}
