package inheritance;

public class A {
	
	//method overriding
	void display(){
		System.out.println("A Class");
	}
	//method overloading;
	void display(String s){
		System.out.println(s);
	}
}
