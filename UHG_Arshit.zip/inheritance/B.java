package inheritance;

public class B extends A{
	void display(){
		System.out.println("B Class");
	}

}
