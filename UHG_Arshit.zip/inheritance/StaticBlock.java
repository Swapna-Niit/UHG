package inheritance;

public class StaticBlock {
	static{
		
		System.out.println(x);
		
	}

}
