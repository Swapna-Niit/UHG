package stringexamples;

import java.util.Scanner;
import java.util.StringJoiner;
import java.util.StringTokenizer;

public class TokenTest {
	
	
	StringJoiner reverseToken(StringTokenizer str){
		StringJoiner sj = new StringJoiner(" ");
		while(str.hasMoreTokens()){
			StringBuffer sb = new StringBuffer(str.nextToken());
			sb.reverse();
			sj.add(sb);
		}
		return sj;
	}
	
	StringJoiner reverseTokenWithoutInbuilt(StringTokenizer str){
		StringJoiner sj = new StringJoiner(" ");
		while(str.hasMoreTokens()){
			char[] arr = str.nextToken().toCharArray();;
			char[] rev = new char[arr.length];
			for(int i=arr.length-1,j=0;i>=0;i--,j++){
				rev[j] = arr[i];
			}
			sj.add(String.valueOf(rev));					
		}
		return sj;			
	}
	
	void displayTokens(StringJoiner sj){
		System.out.println(sj);
		
	}
	
	
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		StringTokenizer st = new StringTokenizer(s, " ");
		
		TokenTest t = new TokenTest();
	//	StringJoiner sj =  t.reverseToken(st);
	//	t.displayTokens(sj);
		//t.reverseTokenWithoutInbuilt(st);
	StringJoiner sj =  t.reverseTokenWithoutInbuilt(st);
	t.displayTokens(sj);
	}


}
