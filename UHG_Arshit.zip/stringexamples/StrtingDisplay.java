package stringexamples;

public class StrtingDisplay {
	

}
