package stringexamples;

import java.util.Scanner;

public class BasicString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		String s1 = "           Examplewq";
		String s2 = new String();
		String s3 = new String("This is the String");
		char[] str = {'a','b','c'};
		String s4 = new String(str);
		System.out.println("Concatenation is "+s1+s2);
		System.out.println("length"+s1.length());
		System.out.println("concat "+s1.concat(s2));
		System.out.println("Sub String"+s1.substring(1,3));
		System.out.println("String "+s1.trim()
		);
		
		
	}

}
