package stringexamples;

import java.util.Scanner;
import java.util.StringJoiner;
import java.util.StringTokenizer;

public class DuplicateChar {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
//		int i=0,j=0;
//		char[] c = s.toCharArray();
//		int[] dup = new int[26];
//		char[] ori = new char[c.length];
//		for(i=0,j=0;i<c.length;i++){
//		//	System.out.println(c[i]);
//			if(dup[c[i]-65] == 1)
//			{
//				ori[j] = c[i];
//				j++;
//			}
//			else
//			dup[c[i]-65] = 1;
//			
//		}
//			for(i=0;i<j;i++){
//				System.out.println(ori[i]);
//			}
//		
		
//		String[] arr = s.split(" ");
//		for(int i=0;i<arr.length;i++){
//			for(int j=0;j<arr.length;j++){
//				if((arr[i].compareToIgnoreCase(arr[j]))==1){
//					
//				}
//			}
//		}
		
		String val1 = "Java Programming";
		String val2 = "Programming Java Language";
//		System.out.println(String.join("-",val1,val2,"Language"));
//		boolean c = val2.regionMatches(12,val1,4,0);
//		System.out.println(c);
		StringBuffer sb = new StringBuffer(val1);
//		sb.append("This is immutable");
//		System.out.println(sb);
//		String str = sb.toString();
//		System.out.println(sb);
		
//		sb.setCharAt(2, 'A');
//		System.out.println(sb);
//		char[] arr = new char[30];
//			sb.getChars(5,16, arr, 0);
//			for(int i=0;i<arr.length;i++)
//				System.out.println(arr[i]);
			
		StringBuilder ss = new StringBuilder(s);
		
		String s1 = "This is java String";
		StringTokenizer st = new StringTokenizer(s1," ");
//		while(st.hasMoreTokens()){
//			if(st.equals("java"))
//			System.out.println("Tokent matched");
//		}
//		
		
//		StringJoiner sj = new StringJoiner(".");
//		sj.add("this");
//		sj.add("is");
//		sj.add("java");
//		sj.add("String");
//		System.out.println(sj);
//		
		


		
	}
	

}
