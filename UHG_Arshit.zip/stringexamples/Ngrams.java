package stringexamples;

import java.util.Arrays;
import java.util.Scanner;

public class Ngrams {
	
	boolean compareNagrams(String s1,String s2){
		
		char[] b1 = s1.toLowerCase().toCharArray();
		char[] b2 = s2.toLowerCase().toCharArray();
		Arrays.sort(b1);
		Arrays.sort(b2);
		String sort1 = String.valueOf(b1);
		String sort2 = String.valueOf(b2);
		//System.out.println(s1.compareToIgnoreCase(s2));	
		if(sort1.compareToIgnoreCase(sort2)==0)
			return true;
		else
			return false;
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s1 = sc.next();
		String s2 = sc.next();
		Ngrams n = new Ngrams();
		System.out.println(n.compareNagrams(s1, s2));

	}

}
