package stringexamples;

import java.util.StringTokenizer;

public class DictonorySort {
	
	void sortWords(String s){
		StringTokenizer st = new StringTokenizer(s, " ");
		String[] sn = 
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
