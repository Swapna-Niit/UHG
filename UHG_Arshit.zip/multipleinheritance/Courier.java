package multipleinheritance;

public class Courier implements City,Address,PostalAddress {

		int j=i;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

	@Override
	public void readAddress() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readCity() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readPostalAddress() {
		// TODO Auto-generated method stub
		
	}

}
