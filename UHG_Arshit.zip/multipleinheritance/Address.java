package multipleinheritance;

public interface Address {
	
	void readAddress();
		

}
