package multipleinheritance;

public interface PostalAddress extends Address,City{
	int i=0;
	void readPostalAddress();


}
