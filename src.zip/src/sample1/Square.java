package sample1;

public class Square extends Triangle{
	
	void countCorners()
	{System.out.println("3 co-rners");	
			
	}
}
 