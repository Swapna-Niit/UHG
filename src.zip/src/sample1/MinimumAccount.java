package sample1;

public class MinimumAccount extends ProtectedAccount {
	int min;
	int penalty;
	
	void read()
	{
		
	}

}
