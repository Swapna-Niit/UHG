package sample1;

public class PhyTeacher extends Teacher {
	
	PhyTeacher()
	{
		System.out.println(" phy salary is 12000");
	}	

}
