package sample1;

public class CDAccount extends ProtectedAccount {
	int penalty;
	int months;

}
