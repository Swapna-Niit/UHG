package sample1;

public class EngTeacher extends Teacher {
	EngTeacher()
	{
		System.out.println(" eng salary is 8000");
	}	


}
