package sample1;

import java.util.Scanner;

public class Lexo {

    public static void main(String[] args) {
    	Scanner ts =new Scanner (System.in);
    	String s;// = { "Cy", "D", "B", "A" };
    	System.out.println("enter the string :" );
    	s=ts.next();
int l=s.length();
        char t[] = s.toCharArray();
    
        for(int i = 0; i < l; ++i) {
            for (int j = i + 1; j < l+1; ++j) {
                if ((t[i])-(t[j])>0) {

                    // swap words[i] with words[j[
                    char temp =t[i];
                    t[i] =t[j];
                   t[j] = temp;
                }
            }
        }

        System.out.println("In lexicographical order:");
        for(int i = 0; i < 4; i++) {
            System.out.println(t[i]);
        }
    }
}