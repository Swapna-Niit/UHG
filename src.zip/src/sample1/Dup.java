package sample1;

//import java.util.Arrays;
//import java.util.Scanner;

public class Dup {

	public static void main(String[] args) {
/*		String s="This is a string";
		
		//Scanner sc=new Scanner(System.in);
		char[] t=new char[10];
		int c=0;
		t=s.toCharArray();
		for(int i=0;i<s.length();i++)
		{
			for(int j=i+1;j<s.length()-1;j++)
			{
	  if(t[i]==t[j]&& t[j]!=' '  )
	  {
		  c++;
		  	  System.out.println(t[i]);
	  }
		
	       
			}
				
		}
		  System.out.println(" ");
		  System.out.println(c);
	}*/

		String s="THIS IS this A";
		String t[]=s.split(" ");
		int c=0;
		for(int i=0;i<t.length;i++)
		{
			for(int j=i+1;j<t.length;j++)
			{ 
	  if(t[i].equals(t[j]))
	  {
		c=1;
		  	  System.out.println(t[j]);
	  }
	       
			}
							
		}
		if(c==0)
			  System.out.println("no dup words");


	}}
