package sample1;



public class Teacher 
{


	Teacher()
	{
		System.out.println("teacher constructor");
		
	}
	
	

}


