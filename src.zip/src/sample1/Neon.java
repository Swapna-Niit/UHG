package sample1;

import java.util.Scanner;

public class Neon {

	public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the number: ");
	int n=s.nextInt();
	int sq=n*n;
	int sum=0;
	
	while(sq!=0)
	{
	int a=sq%10;
		sum=sum+a;
		sq=sq/10;
	}
	if(sum==n)
	{
		System.out.println("neon");
		
	}
	else{
		System.out.println("not");
	}

	}

}
