package sample1;

public class ProtectedAccount extends MainA {

	int newbal,balance;
void correct()
{
if(balance<10000)
{
	newbal=balance;
System.out.println("Balance after Penalty:  " +(newbal));	
}
}
}
