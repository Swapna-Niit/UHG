package sample1;

import java.util.Scanner;

public class Strings {

	public static void main(String[] args) {
Scanner ts =new Scanner (System.in);
		String s="Java Programming";
		//String s1=new String();
		//String s2= new String();
	    String str="Java Programming language";
		//char[] str1={'t','h','i','s'};
	   // String s4=new String(str);
	//   System.out.println("emter rhe string :" );
	//    s2=ts.nextLine();
	//    System.out.println("entered sring is :"+s2);

//System.out.println("this is concat");
//System.out.println("thi is concat"+s1.concat(s2));
//System.out.println("length of the string"+s.length());
//System.out.println(s.hashCode());
//System.out.println(s.equals(str));
//System.out.println(s.length());
//System.out.println(s.trim().length());
	   // System.out.println(s.codePointCount(1, 10));
	/*String arr[]=s.split(" ");
	System.out.println(arr.length);
	for(int i=0;i<arr.length;i++)
	{
		System.out.println(arr[i]			);
	}
	}*/
	    //System.out.println(String.join("-",s,str,"language"));
	
	//boolean c = str.regionMatches(5, s, 5, 11);
	//System.out.println(c);
	StringBuffer sb=new StringBuffer(s);
	StringBuilder sb1=new StringBuilder(s);
	sb.append("  which is immutable");
	System.out.println(sb);
	
	
	String s1=sb.toString();
	System.out.println(s1);
	System.out.println(sb.capacity());
	
	
	}
	
	
}
