package sample1;

import java.util.Scanner;

public class Triangle extends Shape {
		Triangle()
		{
			System.out.println("in triangle");
		}
	 Scanner sc= new Scanner(System.in);
	int l,b,h;
	void readlenght()
	{
	     l=sc.nextInt();
	}
	void readbreadth()
	{
	    b=sc.nextInt();
	}
	
	void readheighth()
	{
		h=sc.nextInt();
	}
	
void countCorners()
{System.out.println("3 corners");	
		
}


void area()

{
	System.out.println(0.5*b*h);
}
void perimeter()
{
	System.out.println(l+b+h);
}
} 