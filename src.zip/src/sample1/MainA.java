package sample1;

import java.util.Scanner;

public class MainA {

	public static void main(String[] args) {
		BasicAccount ba=new BasicAccount();
		Scanner s=new Scanner(System.in);

		float balance;
		float roi;
		double newbal;
		System.out.println("Which type of account");
		System.out.println("1.SBAC "
				+ "2.SALARY "
				+ "3.CURRENT");
		 int a = s.nextInt();
		 
		 switch (a){
		 case 1:ProtectedAccount pa=new ProtectedAccount();
		 break;
		 case 2:MinimumAccount ma=new MinimumAccount();
		 break;
		 case 3:InterestAccount ia=new InterestAccount();
		 break;
		 default:System.out.println("no such option");
		 }

		
	}

}
