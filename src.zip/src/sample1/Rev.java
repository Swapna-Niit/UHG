package sample1;

import java.util.StringTokenizer;

public class Rev {
	String s="this is a string";
    void token()
    {
    	StringTokenizer	 st = new StringTokenizer(s," ");
    	while (st.hasMoreTokens()) {  
            System.out.println(st.nextToken());  
        }  
  
    	
    }
    
    void reve()
    {
    	StringBuilder sb = new StringBuilder(s);
    	sb=sb.reverse();
    	System.out.println(sb);
    	String ab=sb.toString();
    	System.out.println();
    	StringTokenizer	 st1 = new StringTokenizer(ab," ");

    	while (st1.hasMoreTokens()) {  
    		
            System.out.println(st1.nextToken());  
        } 
    	
    }
	public static void main(String[] args) {
	
		Rev r = new Rev();
     r.token();
     r.reve();
 	
	}

}
