package sample1;

public class Shape {
	
	Shape()
	{
		System.out.println("in the shape class");
	}
	void readlenght()
	{
		System.out.println("lenght of the shape");	
	}
	
	void readbreadth()
	{
		System.out.println("breadth of the shape");	
	}
	
void countCorners()
{System.out.println("unpredictable");	
	}
	void area()

	{
	System.out.println("area of the shape");	
	}
void perimeter()
    {
	System.out.println("perimetr of the shape");	
	}
}
