package sample1;

import java.util.Scanner;



		public class BasicAccount {
		 Scanner sc= new Scanner(System.in);
			String name= new String();
			
			float balance;
			float roi;
			double newbal;
		
			void read()
	{
		System.out.println("Enter name: ");
		name=sc.nextLine();
		System.out.println("Enter balance: ");
		balance=sc.nextFloat();
		System.out.println("Enter ROI: ");
		roi=sc.nextFloat();
	}


	

		
	}



