package sample1;

public class InterestAccount extends ProtectedAccount{

}
