package sample1;

import java.util.Scanner;

public class Floyd {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n=s.nextInt();
		
		for (int c = 1 ; c <= n ; c++ )
	      {
	         for ( int d = 1 ; d <= c ; d++ )
	         {
	            System.out.print("*   ");
	           
	         }
	 
	         System.out.println();
	      }
	   }

}
