package sample;

import java.util.Scanner;
/**
 * 
 * @author Trainee Staff
 * Vishakadatta
 */
public class Addition {
	Scanner sc =new Scanner (System.in);
	int firval;
	int secval;
	
	/**
	 * to read data
	 */
    public void read()
    {
    	
    	System.out.println("Enter the first value: ");
    	firval=sc.nextInt();
    	System.out.println("Enter the second value: ");
    	secval=sc.nextInt();
    }

	/**
	 * to sum it up
	 */
	public void add()
     {
		System.out.println("SUM IS :  " +(firval+secval));
     }
}
