package sample;

public class String {
	public static void	main(String...st)
String s="This is a string";
String s=new String();
String s= new String("Hi this third way of creating");
char[] str="char seq to be passed to manipulatr it as string";
String s4=new str
}
