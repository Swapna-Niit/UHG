
package sample;

import java.util.Scanner;

public class SumArray {

	public static void main(String[] args) {
	 Scanner sc= new Scanner(System.in);
	 System.out.println("enter the size of the array ☺5");
	 		 int asize = sc.nextInt();
	 		 char arr[]=new char[asize];
	 		 int sum=0;
	 		 
	 		 for(int i=0;i<asize;i++)
	 		 {
	 			 arr[i]=sc.next().charAt(0);
	 			sum=sum+arr[i];
	 			}
	 		 System.out.println("array is : ");
	 		
	 		 /*for(int i=asize-1;i>=0;i--){
	 			
	
	 		 }*/System.out.println(sum);
	 sc.close();
		}
	
}
