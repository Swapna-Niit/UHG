package sample;

import java.util.Scanner;

public class BitWiseOperator {
	
	Scanner sc = new Scanner(System.in);
	int a,b;
 public void read()
		{
	 System.out.println("Enter the two number: ");
		a=sc.nextInt();
		b=sc.nextInt();
		}
	public void bitAnd()
	{
		System.out.println("Bitwise And: " +(a&b));
	}
		
	public void bitOr()
	{
		System.out.println("Bitwise Or: " +(a|b));
	}
	public void bitNot()
	{
		System.out.println("Bitwise not: " +(~a));
	}
	public void bitExcOr()
	{
		System.out.println("Bitwise excor: " +(a^b));
	}
	public void bitSr()
	{
		System.out.println("Bitwise sr: " +(a>>4));
	}
	public void bitSl()
	{
		System.out.println("Bitwise sl: " +(a<<4));
	}
	public void bitxor()
	{
		System.out.println("Bitwise xor : " +(a^=b));
	}public void bitBAnd()
	{
		System.out.println("Bitwise And: " +(a&=b));
	}
	public void bitBOr()
	{
		System.out.println("Bitwise And: " +(a|=b));
	}
	public void bitSra()
	{
		System.out.println("Bitwise Sra:  " +(a>>=4));
	}
	public void bitSzra()
	{
		System.out.println("Bitwise Szra:  " +(a>>>=4));
	}
	
}



