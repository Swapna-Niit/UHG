package sample;

import java.util.Scanner;

public class DataTypes {

	public static void main(String[] args) {
	 Scanner sc= new Scanner(System.in);
	 System.out.println("enter the size of the array");
	 		 int asize = sc.nextInt();
	 		 int arr[]=new int[asize];
	 		 int sum=0;
	 		 for(int i=asize-1;i>=0;i--)
	 		 {
	 			 System.out.println("enter the " + i +"th"+" element");

     
	 			 arr[i]=sc.nextInt();
	 			 		sum=sum+arr[i];	
	 		 }
	 		 System.out.println("sum is : " +sum);
	 		 /*for(int j=0;j<asize;j++){
	 		 
System.out.println();	
	 		 }*/
	 sc.close();
		}
	
}