package sample;

public class ArithmaticOperatoin {

	public static void main(String[] args) {
	
		/*Addition ad =new Addition();
		ad.read();
		ad.add();*/
		BitWiseOperator bo = new BitWiseOperator();
		bo.read();
		bo.bitAnd();
		bo.bitOr();
		bo.bitNot();
		bo.bitExcOr();
		bo.bitSr();
		bo.bitSl();
		bo.bitSra();
		bo.bitBAnd();
		bo.bitBOr();
		bo.bitxor();
		bo.bitSzra();
		
		
	}

}
