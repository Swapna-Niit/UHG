package sample;
import java.lang.String;
public class Strings {

	public static void main(String[] args) {
		String s="This is a string";
		String s1=new String();
		String s2= new String();
	    String str="char seq to be passed to manipulatr it as string";
		String s4=new String(str);

	}

}
