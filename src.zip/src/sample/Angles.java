package sample;

import java.util.Scanner;

public class Angles {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the angles: ");
		int ang1=sc.nextInt();
		int ang2=sc.nextInt();
		int ang3=sc.nextInt();
		if(ang1+ang2+ang3!=180)
		{
			System.out.println("IS NOT A TRIANGLE");
			
			
		}
		if(ang1==90 || ang2==90 || ang3==90)
	
		{
			System.out.println("is a right angle triangle");
		}
		else
		{
			System.out.println("is a not right angle triangle");
		}

	}

}
