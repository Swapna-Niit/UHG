package sample;

 public class AccessModifier {
	public void printInfo()
	 {
		 System.out.println("in printInfo method in access modifier ");
	 }

}
