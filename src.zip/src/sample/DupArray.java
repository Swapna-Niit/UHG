package sample;

import java.util.Scanner;

public class DupArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 System.out.println("enter the size of the array ");
		 int asize = sc.nextInt();
 		 char arr[]=new char[asize];
 		int j=0,c=0;
 		 System.out.println("enter the characters to the array ");
 		for(int i=0;i<asize;i++)
		 {
			 arr[i]=sc.next().charAt(0);
			
			}
 		
 		for(int i=0;i<asize;i++)
	
 			{
 			for(j=i+1;j<asize;j++)
 				c++;
 			
			 if(arr[i]==arr[j])
			 {
				 System.out.println("duplicate found") ;
				 break;
			 }

		 		if(c==2*asize)
		 			System.out.println("np duplicates");
			}
	
	}

	}


