package sample;

import java.util.Scanner;

public class Spy {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
	System.out.println("enter the number");
	int num=sc.nextInt();
	int n1=num;
	int n2=num;
	int c1=0;
	int c2=1;
	if(num==0)
	{
		System.out.println("spy");
	
	}
	else{
	while(n1!=0)
	{
		c1=c1+(n1%10);
		n1=n1/10;
		
	}
	while(n2!=0)
	{
		c2=c2*(n2%10);
		n2=n2/10;
		
	}
	if(c1==c2)
	{
		System.out.println("spy");
		
	}
	else 
	{
		System.out.println("not");
	}
	}
	}
}
