package sample;

public interface DataBase {
	
    int a=30;
    void connectDB();
    default void ConnectionValues()
    {
    	System.out.println("reads the DB URL AND UNAME"
    			+ "AND PWD");
    }
    static void values()
    {
    	System.out.println("reads the DB URL AND UNAME"
    			+ "AND PWD");
    }
}
