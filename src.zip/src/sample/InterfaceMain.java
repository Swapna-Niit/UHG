package sample;

public class InterfaceMain {

	public static void main(String[] args) {
		
		DataBaseimpl ddbi=new DataBaseimpl();
		ddbi.ConnectionValues();
		ddbi.connectDB();             
		
	}

}
